#include<iostream>
#include<cstring>
using namespace std;
class bankaccount
{
	int accum,balance;
	char name[50];
	public:
		void set_data()
		{
			cout<<"Enter The Name ,Acc no & balance: "<<endl;
			cin>>name>>accum>>balance;
		}
		void get_data()
		{
			cout<<name<<" "<<accum<<" "<<balance<<endl;
		}
		void deposite(int amt)
		{
			balance+=amt;
			cout<<"Amount Deposited Succefully"<<endl;
		}
		friend void withdrawamount(bankaccount &acc,int amt);
		friend void checkbalance(bankaccount &acc);

};

void withdrawamount(bankaccount &acc,int amt)
{
	if(acc.balance>amt)
	{
		acc.balance-=amt;
		cout<<"Amount Withdraw Succefully"<<endl;
	}
	else
	cout<<"Insufficient Balance"<<endl;

}

void checkbalance(bankaccount &acc)
{
	cout<<"Balance: "<<acc.balance<<endl;

}

int main()
{
	int n,i,custno,op,withamt,depoamt;
	cout<<"Enter The Number Of Customer: "<<endl;
	cin>>n;
	bankaccount **customer;
	customer=new bankaccount*[n];
	for(i=0;i<n;i++)
	{
		customer[i]=new bankaccount;
	}
	for(i=0;i<n;i++)
	{
		customer[0][i].set_data();
	}
	while(1)
	{
		cout<<"Enter The Acc no that you want to access: "<<endl;
		cin>>custno;
		cout<<"Enter The Option\n1.Withdraw\n2.Deposite\n3.Check Balance\n4.Display Deatils\n5.Exit"<<endl;
		cin>>op;
		if(custno<=n)
		{
			switch(op)
			{
				case 1:
					cout<<"Enter The Amount For Withdraw: "<<endl;
					cin>>withamt;
					withdrawamount(customer[0][custno],withamt);
					break;
				case 2:	
					cout<<"Enter The Amount For Deposite: "<<endl;
					cin>>depoamt;
					customer[0][custno].deposite(depoamt);
					break;
				case 3:
					checkbalance(customer[0][custno]);
					break;
				case 4:
					customer[0][custno].get_data();
					break;
				case 5:return 0;
				default:cout<<"Invalid Option"<<endl;
					break;
			}
		}
		else
			cout<<"Account Is Not Available\n";

	}
	for(i=0;i<n;i++)
	{
		delete customer[i];
	}
	delete customer;
}

