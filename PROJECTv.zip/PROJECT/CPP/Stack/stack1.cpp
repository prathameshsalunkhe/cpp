#include<iostream>
using namespace std;
#define max_size 5
template<class type>
class Stack_Op
{
	int index;
	type stk[max_size];
	public:
	Stack_Op()
	{
		index=-1;
	}
	void stack_operation();
	void push();
	void pop();
	void display();
};
template<class type>
void Stack_Op<type>::push()
{
	type ele;
	cout<<"\033[31menter element\033[0m"<<endl;
	cin>>ele;
	if(index>=max_size-1)
	{
		cout<<"\033[36mstack overflow\033[0m"<<endl;
	}
	else
		index++;
	stk[index]=ele;
}

template<class type>
void Stack_Op<type>::pop()
{
	if(index<=-1)
		cout<<"\033[36mstack is underflow\033[0m"<<endl;
	else
		cout<<"\033[36mdeleted : \033[0m"<<stk[index]<<endl;
	index--;
}

template<class type>
void Stack_Op<type>::display()
{
	if(index<=-1)
	{
		cout<<"\033[36mstack is empty\033[0m"<<endl;
	}
	else
	{
		for(int i=0;i<=index;i++)
			cout<<stk[i]<<" ";
		cout<<endl;
	}
}

template<class type>
void  Stack_Op<type>::stack_operation()
{
	int sub_op;
	cout<<"\033[36m stack application ready to use\033[0m"<<endl;
	while(1)
	{
		cout<<"1.push 2.pop 3.display_stack 4.main_menu"<<endl;
		cout<<"Enter sub menu"<<endl;
		cin>>sub_op;

		switch(sub_op)
		{
			case 1:cout<<"\033[36mpush data on stack\033[0m"<<endl;
			       push();
			       break;
			case 2:cout<<"\033[36mpop data \033[0m"<<endl;
			       pop();
			       break;
			case 3:cout<<"\033[36mdisplay_stack\033[0m"<<endl;
			       display();
			       break;
			case 4:return;break;
		}
	}
}
int main()
{
	int m_op,sub_op,stk_op,count=1;
	Stack_Op<int>obj1;
	Stack_Op<char>obj2;
	Stack_Op<float>obj3;
	Stack_Op<double>obj4;
	Stack_Op<string>obj5;

	while(1)
	{
	lebal:
		cout<<"1)int 2)char 3)float 4)doube 5)string 6)exit "<<endl;
		cout<<"enter main option"<<endl;
		cin>>m_op;
		switch(m_op)
		{
			case 1:obj1.stack_operation();count=3;break;
			case 2:obj2.stack_operation();count=3;break;
			case 3:obj3.stack_operation();count=3;break;
			case 4:obj4.stack_operation();count=3;break;
			case 5:obj5.stack_operation();count=3;break;
			default:count++;
			if(count==2)
			{
				cout<<"\033[36mPlease read option carefully\033[0m"<<endl;
				goto lebal;
			}
			else if(count==3)
			{
				cout<<"\033[36mlast chance please take care\033[0m"<<endl;
				goto lebal;
			}	
			else
			{
				cout<<"\033[36mthanks for using our application\033[0m"<<endl;
				cout<<"\033[31mplease read the manual and come back properly"<<endl;
				exit(0);
			}
			break;

		}
	}
}
