#include<iostream>
using namespace std;
#define max_size 5

template<class type>
class Stack_Op;

template<class type>
void stack_operation(Stack_Op<type>&);

template<class type>
void push(Stack_Op<type>&);

template<class type>
void pop(Stack_Op<type>&);

template<class type>
void display(Stack_Op<type>&);

template<class type>
class Stack_Op {
	int index;
	type stk[max_size];

	public:
	Stack_Op() 
	{
		index = -1;
	}

	friend void stack_operation<type>(Stack_Op<type>&);
	friend void push<type>(Stack_Op<type>&);
	friend void pop<type>(Stack_Op<type>&);
	friend void display<type>(Stack_Op<type>&);
};

template<class type>
void push(Stack_Op<type>& obj) 
{
	type ele;
	cout << "\033[31menter element\033[0m" << endl;
	cin >> ele;
	if (obj.index >= max_size - 1) 
	{
		cout << "\033[36mstack overflow\033[0m" << endl;
	} 
	else
	{
		obj.index++;
		obj.stk[obj.index] = ele;
	}
}

template<class type>
void pop(Stack_Op<type>& obj) 
{
	if (obj.index <= -1) 
	{
		cout << "\033[36mstack is underflow\033[0m" << endl;
	} 
	else 
	{
		cout << "\033[36mdeleted : \033[0m" << obj.stk[obj.index] << endl;
		obj.index--;
	}
}

template<class type>
void display(Stack_Op<type>& obj) 
{
	if (obj.index <= -1) 
	{
		cout << "\033[36mstack is empty\033[0m" << endl;
	}
	else 
	{
		for (int i = 0; i <= obj.index; i++)
			cout << obj.stk[i] << " ";
			cout << endl;
	}
}

template<class type>
void stack_operation(Stack_Op<type>& obj) 
{
	int sub_op,sub_op1;
	cout << "\033[36m stack application ready to use\033[0m" << endl;
	while (1) 
	{
		cout << "1.push 2.pop 3.display_stack 4.main_menu" << endl;
		cout << "Enter sub menu" << endl;
		cin >> sub_op;

		switch (sub_op) 
		{
			
			case 1: 
				cout<<"Enter Sub op1)old Stack 2)New Stack"<<endl;
				cin>>sub_op1;
				if(sub_op1==1)
				obj.index=obj.index;
				else if(sub_op1==2)
				obj.index=-1;
				cout << "\033[36mpush data on stack\033[0m" << endl;
				push(obj); break;
			case 2: cout<<"Enter Sub op1)old Stack 2)New Stack"<<endl;
				cin>>sub_op1;
				if(sub_op1==1)
				obj.index=obj.index;
				else if(sub_op1==2)
				obj.index=-1;
				cout << "\033[36mpop data \033[0m" << endl;
				pop(obj); break;
			case 3: cout<<"Enter Sub op1)old Stack 2)New Stack"<<endl;
				cin>>sub_op1;
				if(sub_op1==1)
				obj.index=obj.index;
				else if(sub_op1==2)
				obj.index=-1;
				cout << "\033[36mdisplay_stack\033[0m" << endl;
				display(obj); break;
			case 4: return;
		}
	}
}

int main() 
{
	int m_op, count = 3;
	Stack_Op<int> obj1;
	Stack_Op<char> obj2;
	Stack_Op<float> obj3;
	Stack_Op<double> obj4;
	Stack_Op<string> obj5;

	while (1) 
	{
		lebal:
			cout << "1)int 2)char 3)float 4)double 5)string 6)exit " << endl;
			cout << "enter main option" << endl;
			cin >> m_op;

		switch (m_op) 
		{
			case 1: stack_operation(obj1); count = 3; break;
			case 2: stack_operation(obj2); count = 3; break;
			case 3: stack_operation(obj3); count = 3; break;
			case 4: stack_operation(obj4); count = 3; break;
			case 5: stack_operation(obj5); count = 3; break;
			default:
				count--;
				if (count == 2) 
				{
					cout << "\033[36mPlease read option carefully\033[0m" << endl;
					goto lebal;
				} 
				else if (count == 1) 
				{
					cout << "\033[36mlast chance please take care\033[0m" << endl;
					goto lebal;
				} 
				else
				{
				      cout <<"\033[36mthanks for using our application\033[0m" << endl;
				      cout <<"\033[31mplease read the manual and come back properly"<<endl;
				      exit(0);
				}
		}
	}
}

