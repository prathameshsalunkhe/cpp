
STRING::STRING()
{
	s=new char[1];
	s[0]=0;
}

STRING::STRING(const char *p)
{
	if(p){
		s=new char[my_strlen(p)+1];
		my_strcpy(s,p);
	}else{
		s=new char[1];
		s[0]=0;
	}
}

STRING::STRING(STRING &p)
{
	if(p.s){
		s=new char[my_strlen(p.s)+1];
		my_strcpy(s,p.s);
	}
	else{
		s=new char[1];
		s[0]=0;
	}
}

STRING::~STRING()
{

	delete s;
}

STRING& STRING::operator =(STRING t)
{
	my_strcpy(s,t.s);
	return *this;
}

int STRING::my_strlen()
{
	if(s!=0)
	{
		int len;
		for(len=0;s[len];len++);
		return len;
	}
	else
	{
		cout<<"USAGE : Store Valid String First Using scan_string()"<<endl;
		return 0;
	}
}

int STRING::my_strlen(const char *p)
{
	int len;
	for(len=0;p[len];len++);
	return len;
}

void STRING::my_strcpy(char *d,const char *sr)
{
	int i;
	for(i=0;sr[i];i++)
		d[i]=sr[i];
}

void STRING::scan_string()
{
	s=new char[50];
	cout<<"Enter The String"<<endl;
	cin.getline(s,50);
}


