void my_strcpy(STRING &d,constSTRING &sr)
{
	int i;
	delete d.s;
	d.s=new char[my_strlen(sr.s)+1];
	for(i=0;sr.s[i];i++)
		d.s[i]=sr.s[i];
	d.s[i]=sr.s[i];

}

void my_strncpy(STRING &d,const STRING &sr,int n)
{
	int i,d_len=my_strlen(d.s),sr_len=my_strlen(sr.s);
	if(d_len>=n || d_len>=sr_len)
	{
		for(i=0;i<n;i++)
			d.s[i]=sr.s[i];
			d.s[i]='\0';
	}
	else
	{
		delete d.s;
		d.s=new char[d_len+n+1];
		for(i=0;i<n;i++)
			d.s[i]=sr.s[i];
			d.s[i]='\0';
	}
}

int my_strlen(const char *p)
{
	int len;
		for(len=0;p[len];len++);
		return len;

}

int my_strlen(STRING &p)
{
	if(p.s==0)
	{
		cout<<"USAGE : Store Valid String First using scan_string()"<<endl;
		return 0;
	}
	else
	{
		int len;
		for(len=0;p.s[len];len++);
		return len;
	}
}

void my_strcat(STRING &d,STRING &sr)
{
	int len,i;
	len=my_strlen(d.s);
	for(i=0;sr.s[i];i++)
		d.s[len+i]=sr.s[i];
		d.s[len+i]='\0';
}

char* my_strncat(STRING &d,STRING &sr,int n)
{
	int len,i;
	len=my_strlen(d.s);
	for(i=0;i<n;i++)
		d.s[len+i]=sr.s[i];
		d.s[len+i]='\0';
}

int my_strcmp(const STRING &m,const STRING &r)
{
	int i,j,len1=my_strlen(m.s),len=my_strlen(r.s);
	if(len1>=len)
	{
		for(i=0,j=0;i<len1;i++,j++)
			if(m.s[i]>r.s[j])
				return 1;
			else if(m.s[i]<r.s[j])
				return -1;
			return 0;
	}
	else
	{
		for(i=0,j=0;i<len;i++,j++)
			if(m.s[i]>r.s[j])
				return 1;
			else if(m.s[i]<r.s[j])
				return -1;
			return 0;
	}
}

int my_strncmp(const STRING &m,const STRING &r,int n)
{
	int i,j,len1=my_strlen(m.s),len=my_strlen(r.s);
	if(len1>=len)
	{
		for(i=0,j=0;i<len1;i++,j++)
			if(i<n)
			{
				if(m.s[i]>r.s[j])
					return 1;
				else if(m.s[i]<r.s[j])
					return -1;
			}
		return 0;
	}
	else
	{
		for(i=0,j=0;i<len;i++,j++)
			if(i<n)
			{
				if(m.s[i]>r.s[j])
					return 1;
				else if(m.s[i]<r.s[j])
					return -1;
				return 0;
			}
	}
}

const char* my_strchr(STRING &sr,char ch)
{
	int i;
	for(i=0;sr.s[i];i++)
	{
		if(sr.s[i]==ch)
		{
			cout<<"Charater Is Present"<<endl;
			return &sr.s[i];
		}
	}
	cout<<"Character Is Not Present"<<endl;
		return NULL;
}

const char* my_strrchr(STRING &sr,char ch)
{
	int i,len;
	len=my_strlen(sr.s);
	for(i=len-1;i>=0;i--)
	{
		if(sr.s[i]==ch)
			cout<<"Charater Is Present"<<endl;
			return &sr.s[i];
	}
	cout<<"Character Is Not Present"<<endl;
		return NULL;
}

const char* my_strstr(STRING &d,const char *sr)
{
	int i,j,k;
	for(i=0;d.s[i];i++)
	{
		if(d.s[i]==sr[0])
		{
			for(j=1,k=i+1;sr[j];j++,k++)
			{
				if(d.s[k]!=sr[j])
				break;
			}
			if(d.s[k-1]==sr[j-1])
			{
				cout<<"Substring Is Present"<<endl;
				return &d.s[i];
			}
		}
	}
	cout<<"Substring Is Not Present"<<endl;
	return NULL;
}

void my_strrev(STRING &sr)
{
	int i,len;
	char temp;
	len=my_strlen(sr.s);
	for(i=0,len=len-1;i<len;i++,len--)
	{
		temp=sr.s[i];
		sr.s[i]=sr.s[len];
		sr.s[len]=temp;
	}
}

void my_strlower(STRING &d)
{
	int i;
	for(i=0;d.s[i];i++)
		if(d.s[i]>='A' && d.s[i]<='Z')
			d.s[i]+=32;
}

void my_strupper(STRING &d)
{
	int i;
	for(i=0;d.s[i];i++)
		if(d.s[i]>='a' && d.s[i]<='z')
			d.s[i]-=32;
}

void my_strtoggle(STRING &d)
{
	int i;
	for(i=0;d.s[i];i++)
		if((d.s[i]>='A' && d.s[i]<='Z')||(d.s[i]>='a' &&d.s[i]<='z'))
			d.s[i]^=32;
}

ostream & operator << (ostream &out,STRING &d)
{
	out<<d.s<<endl;
	return out;
}

istream & operator >> (istream &in,STRING &d)
{
	in>>d.s;
	return in;
}


