#include<iostream>
#include<cstring>
using namespace std;

int my_strlen(const char *);

class STRING
{
	char *s;
	public: 
		STRING();
		STRING(const char *);
		STRING(STRING &);
		~STRING();
		STRING& operator =(STRING);
		int my_strlen();
		int my_strlen(const char *);
		void my_strcpy(char *,const char *);
		void scan_string();
		
		friend void my_strcpy(STRING &,STRING &);
		friend void my_strncpy(STRING &,const STRING &,int);
		friend int my_strlen(STRING &);
		friend void my_strcat(STRING &,STRING &);
		friend char* my_strncat(STRING &,STRING &,int);
		friend int my_strcmp(const STRING &,const STRING &);
		friend int my_strncmp(const STRING &,const STRING &,int);
		friend const char* my_strchr(STRING &,char);
		friend const char* my_strrchr(STRING &,char); 
		friend const char* my_strstr(STRING &,const char *);
		friend void my_strrev(STRING &);
		friend void my_strlower(STRING &);
		friend void my_strupper(STRING &);
		friend void my_strtoggle(STRING &);

		friend ostream & operator <<(ostream &,STRING &);
		friend istream & operator >>(istream &,STRING &);
};


#include"my_own_string.cpp"
#include"string.cpp"


