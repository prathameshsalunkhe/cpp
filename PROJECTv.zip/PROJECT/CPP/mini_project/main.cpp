
#include"header.h"

int main()
{	
	int len;
	STRING s;
	s.my_strlen();
	STRING s1("AbCd"),s2(s1),s3("1234");
	my_strlen(s2);
	s2.scan_string();
	//cout<<"s2: "<<s2;
	//cout<<"s2: "<<s2;
	//my_strcpy(s2,s1);
	//cout<<"s2: "<<s2;
	/*my_strcat(s1,s2);
	cout<<"s2: "<<s2;
	const char *p;
	my_strchr(s2,'C');
	cout<<"s1: "<<s1;
	my_strrev(s1);
	cout<<"s1: "<<s1;
	cout<<"s2: "<<s2;
	my_strtoggle(s2);
	cout<<"s2: "<<s2;*/
}
