#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void header(char *,int );
void path_fun(char *);
void micro_fun(char *s,int len);
void replace_fun(char *n,char *b);
FILE *fd,*fr;
char **gs;
int line=0;
void main(int argc,char **argv)
{
        if(argc!=2)
        {
                printf("USAGE:./a.out filename\n");
                return;
        }

        FILE *fp=fopen(argv[1],"r");
        FILE * fd=fopen("data.i","a");
        char ch;
        int c=0,c1=0,i;
        while((ch=fgetc(fp))!=EOF)
        {
                c1++;
                if(ch=='\n')
                {
		line++;
                        if(c<c1)
                                c=c1;
                        c1=0;
                }
        }
        rewind(fp);

        char *s=malloc(c+1);
        int len=strlen("#include");

        while(fgets(s,c+1,fp))
                header(s,len);
/*============================= Micro ==============================*/

	rewind(fp);
         len=strlen("#define");
      gs=malloc(sizeof(char *)*line);
        for(i=0;i<line;i++)
        {
                gs[i]=malloc(c+1);
                fgets(gs[i],c+1,fp);
        }
        rewind(fp);
        while(fgets(s,c+1,fp))
                micro_fun(s,len);
         fd=fopen("data.i","a");
        for(i=0;i<line;i++)
        fputs(gs[i],fd);
	fclose(fd);
/*============================= Comment ==============================*/
 rewind(fp);
	fclose(fp);
        fp=fopen(argv[1],"r");

        fd=fopen("data.i","a");
	fr=fopen("temp","w");
        while(fgets(s,c+1,fp))
        {
		printf("Enter\n");
                if(strstr(s,"//"))
                        continue;
                else if(strstr(s,"/*"))
                {
                        while(fgets(s,c+1,fp))
                        {
                                if(strstr(s,"*/"))
                                        break;
                        }
                }
                else
                        fputs(s,fr);
        }

}

void header(char *s,int len)
{
        int i,c;
        char t[20],p[200]="/usr/include/";
        if(strstr(s,"#include"))
        {
                for(i=len+1,c=0;s[i]!='>'&&s[i]!='"';i++)
                        t[c++]=s[i];
                t[c]='\0';
                strcat(p,t);
        }
        if(s[len]=='<')
        {
                path_fun(p);
        }

        else if(s[len]=='"')
        {       FILE *tp=fopen(t,"r");
                if(tp==0)
                path_fun(p);
                else
                path_fun(t);
        }

}
void path_fun(char *p)
{
        int c=0,c1=0;
        char ch;
        FILE *path=fopen(p,"r");
        while((ch=fgetc(path))!=EOF)
        {
                c1++;
                if(ch=='\n')
                {
                        if(c<c1)
                                c=c1;
                        c1=0;
                }
        }
        rewind(path);
        char *s=malloc(c+1);
        while(fgets(s,c+1,path))
                fputs(s,fd);

}

void micro_fun(char *s,int len)
{
        int i,n,j;
        char name[200],body[1000];
        if(strstr(s,"#define"))
        {
                for(i=len+1,n=0;s[i]!=' ';i++)
                        name[n++]=s[i];
                name[n]='\0';

                for(j=i+1,n=0;s[j]!='\0';j++)
                        body[n++]=s[j];
                body[n]='\0';

                replace_fun(name,body);
        }
}


void replace_fun(char *n,char *b)
{
        char *p,c=0,t[200];
        int len1=strlen(n),len2=strlen(b),i;
        FILE *fp=fopen("data","r");
        for(i=0;i<line;i++)
        {
                p=gs[i];
                if(p=strstr(gs[i],n))
                {
                        if(c==0)
                        {
                                c=1;
                                continue;
                        }
                        strcpy(t,p+len1);
                        strcpy(p,b);
                        strcpy((p+len2-1),t);

                }
        }
}

