#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void micro_fun(char *,int);
void replace_fun(char *,char *);
char **gs;
int line;
void micro(char *argv)
{

      
        rewind(fp);
        char *s=malloc(c+1);
        int len=strlen("#define"),i;
        gs=malloc(sizeof(char *)*line);
        for(i=0;i<line;i++)
        {
                gs[i]=malloc(c+1);
                fgets(gs[i],c+1,fp);
        }
        rewind(fp);

        while(fgets(s,c+1,fp))
                micro_fun(s,len);
        FILE *fd=fopen("data.i","a");
        for(i=0;i<line;i++)
        fputs(gs[i],fd);
}


void micro_fun(char *s,int len)
{
        int i,n,j;
        char name[200],body[1000];
        if(strstr(s,"#define"))
        {
                for(i=len+1,n=0;s[i]!=' ';i++)
                        name[n++]=s[i];
                name[n]='\0';

                for(j=i+1,n=0;s[j]!='\0';j++)
                        body[n++]=s[j];
                body[n]='\0';

                replace_fun(name,body);
        }
}


void replace_fun(char *n,char *b)
{
        char *p,c=0,t[200];
        int len1=strlen(n),len2=strlen(b),i;
        FILE *fp=fopen("data","r");
        for(i=0;i<line;i++)
        {
                p=gs[i];
                if(p=strstr(gs[i],n))
                {
                        if(c==0)
                        {
                                c=1;
                                continue;
                        }
                        strcpy(t,p+len1);
                        strcpy(p,b);
                        strcpy((p+len2-1),t);

                }
        }
}
