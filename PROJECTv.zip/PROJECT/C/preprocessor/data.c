#include"header.h"
#include<stdio.h>
#define INTEGER int
#define FLOAT float
int main(){
INTEGER k=abc;
FLOAT f=23.5;
INTEGER i=10;
// abcde
pf("%d %d\n",k,coding);
/* 12424 fs
dgfdgfdg */
INTEGER k=500;
FLOAT n=10.32;
}

