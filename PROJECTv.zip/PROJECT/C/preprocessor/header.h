struct st
{
	int i;
	char ch;
	float f;
}
void comment(char *);
void micro(char*);
