#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void header(char *,int );
void path_fun(char *);
FILE *fd;
void main(int argc,char **argv)
{
        if(argc!=2)
        {
                printf("USAGE:./a.out filename\n");
                return;
        }
        FILE *fp=fopen(argv[1],"r");
        fd=fopen("data.i","a");
        char ch;
        int c=0,c1=0;
        while((ch=fgetc(fp))!=EOF)
        {
                c1++;
                if(ch=='\n')
                {
                        if(c<c1)
                                c=c1;
                        c1=0;
                }
        }
        rewind(fp);

        char *s=malloc(c+1);
        int len=strlen("#include");

        while(fgets(s,c+1,fp))
                header(s,len);

comment(argv[1]);
micro(argv[1]);
}

void header(char *s,int len)
{
        int i,c;
        char t[20],p[200]="/usr/include/";
        if(strstr(s,"#include"))
        {
                for(i=len+1,c=0;s[i]!='>'&&s[i]!='"';i++)
                        t[c++]=s[i];
                t[c]='\0';
                strcat(p,t);
        }
        if(s[len]=='<')
        {
                //p[200]="/usr/include/";
                path_fun(p);
        }

        else if(s[len]=='"')
        {       FILE *tp=fopen(t,"r");
                if(tp==0)
                path_fun(p);
                else
                path_fun(t);
        }


}


void path_fun(char *p)
{
        int c=0,c1=0;
        char ch;
        FILE *path=fopen(p,"r");
        while((ch=fgetc(path))!=EOF)
        {
                c1++;
                if(ch=='\n')
                {
                        if(c<c1)
                                c=c1;
                        c1=0;
                }
        }
        rewind(path);
        char *s=malloc(c+1);
        while(fgets(s,c+1,path))
                fputs(s,fd);

}


