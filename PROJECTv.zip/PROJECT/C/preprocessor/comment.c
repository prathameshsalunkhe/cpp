#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void comment(char *argv)
{
        /*if(argc!=2)
        {
                printf("USAGE:./a.out filename\n");
                return;
        }*/

        FILE *fp=fopen(argv,"r");
        if(fp==0)
        {
                printf("file is not present\n");
                return;
        }

        char ch;
        int c=0,c1=0;
        while((ch=fgetc(fp))!=EOF)
        {
                c1++;
                if(ch=='\n')
                {
                        if(c<c1)
                                c=c1;
                        c1=0;
                }
        }
        rewind(fp);
        char *s=malloc(c+1);
        FILE *fd=fopen("data.i","a");
        while(fgets(s,c+1,fp))
        {
                if(strstr(s,"//"))
                        continue;
                else if(strstr(s,"/*"))
                {
                        while(fgets(s,c+1,fp))
                        {
                                if(strstr(s,"*/"))
                                        break;
                        }
                }
                else
                        fputs(s,fd);
        }
}

