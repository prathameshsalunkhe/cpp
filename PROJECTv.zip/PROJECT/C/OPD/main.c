#include"header.h"
void main()
{	
	int n;
	P *p;
	printf("Enter The Number Of Patient: \n");
	scanf("%d",&n);

	p=malloc(sizeof(P)*n);

	
}
