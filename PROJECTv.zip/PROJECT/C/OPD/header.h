#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define FILENAME "opd_records.txt"

typedef struct Patient
{
	int id;
	char name[50];
	int age;
	char disease[50];
	char department[30];
}P;
