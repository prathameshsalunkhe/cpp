#include <LPC21xx.H>
#define LED 1<<17
#define SW1 ((IOPIN0>>14)&1)
#define SW2 ((IOPIN0>>15)&1)
main()
{	   
	int c=0,d=0;
	IODIR0=LED;
	IOSET0=LED;
	while(1)
	{
		if(SW1==0)
		{
			while(SW1==0);
			c++;
			if(c%2==0)
				IOSET0=LED;
			else
				IOCLR0=LED;
		}
		else if(SW2==0)
		{
			while(SW2==0);
		  	d++;
			if(d%2==0)
				IOCLR0=LED;
			else 
				IOSET0=LED;
		}

	}
}
