#include <LPC21xx.H>
#include"header.h"
#define LED 1<<17
#define SW ((IOPIN0>>14)&1)
main()
{
int r;
IODIR0=LED;
IOSET0=LED;
while(1)
{
if(SW==0)
{
r=delay_sec(1);
if(r==2)
IOCLR0=LED;
else if(r==1)
IOSET0=LED;
}
}
}
