#include <LPC21xx.H>
#include"header.h"
#define LED 1<<17
#define SW ((IOPIN0>>14)&1)
main()
{
	int c=0;
	IODIR0=LED;
	IOSET0=LED;
	while(1)
	{
 		while(T0TC<1);
		{
 		 if(SW==0)
		 {
		   while(SW==0);
		   c++;
		 }  
		}
		c=0;	
	}
}
