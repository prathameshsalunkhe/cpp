#include <LPC21xx.H>
#include"header.h"
#define LED 0x24082408<<0
main()
{
//Active LL;
IODIR0=LED;
while(1)
{
IOCLR0=LED;
delay_ms(500);
IOSET0=LED;
delay_ms(500);
}
} 

/*{
Active HL
IODIR0=LED;
while(1)
{
IOSET0=LED;
delay_ms(500);
IOCLR0=LED;
delay_ms(500);
}
} */
