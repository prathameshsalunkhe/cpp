#include <LPC21xx.H>
 #define SW ((IOPIN0>>14)&1)
void delay_ms(unsigned int ms)
{
T0PC=0;
T0PR=15000-1;
T0TC=0;
T0TCR=1;
while(T0TC<ms);
T0TCR=0;
}

int delay_sec(unsigned int sec)
{
int c=0;
T0PC=0;
T0PR=15000000-1;
T0TC=0;
T0TCR=1;
while(T0TC<sec)
{
   if(SW==0)
   {
   while(SW==0);
   c++;
   }
}
T0TCR=0;
return c;
}

