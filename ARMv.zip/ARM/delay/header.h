extern void delay_ms(unsigned int ms);
extern void delay_sec(unsigned int sec);