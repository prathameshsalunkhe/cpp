#include<LPC21xx.H>
#include"header1.h"
main()
{
delay_ms(200);
delay_sec(2);
}
