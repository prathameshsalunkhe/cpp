#include <LPC21xx.H>
 main()
 {
  //IODIR0=0X0700;
  //IODIR0=1792;
  //IODIR0=1792<<0;
  //IODIR0=0X0700<<0;
  //IODIR0=7<<8;
  //IODIR0=03400;
  IODIR0=0X07<<8;
  }
