#include <LPC21xx.H>
#include"header.h"
main()
{
lcd_init();
lcd_data('A');
lcd_data('B');
lcd_data('C');
}
