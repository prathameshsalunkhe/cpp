void delay_ms(unsigned int ms);
void delay_sec(unsigned int sec);
void lcd_data(unsigned char data);
void lcd_cmd(unsigned char cmd);
void lcd_init();
