#include <LPC21xx.H>
#include"header.h"
int main()
{
uart0_init(9600);
uart0_tx('R');
}
