#include <LPC21xx.H>
#include"header.h"
int main()
{
uart0_init(9600);
uart0_tx_string("\r\nPositive Number");
uart0_integer(12345);
uart0_tx_string("\r\nNegative Number");
uart0_integer(-54321);
}
