#include <LPC21xx.H>
#include"header.h"
#define SW (IOPIN0>>14&1)
int main()
{
	int count=0;
	uart0_init(9600);
	
	while(1)
	{
		if(SW==0)
		{
			while(SW==0);
			count++;
	
			uart0_tx(count/10+48);
			uart0_tx(count%10+48);
			uart0_tx('\r');
			uart0_tx('\n');
				
			if(count==59)
			count=0;
		}
	}
}


