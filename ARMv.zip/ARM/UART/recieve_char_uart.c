#include <LPC21xx.H>
#include"header.h"
int main()
{
	unsigned int temp;
	uart0_init(9600);
	while(1)
	{
		//Loopback
		temp=uart0_rx();
		uart0_tx(temp);
	}
}

