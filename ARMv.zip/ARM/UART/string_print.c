#include <LPC21xx.H>
int main()
{
int i;
char *p="RUSHIKESH SUDAM KOLI";
PINSEL0=0X5;
U0LCR=0X83;
U0DLL=97;
U0DLM=0;
U0LCR=0X3;
for(i=0;p[i];i++)
{
U0THR=p[i];
while((U0LSR>>5&1)==0);
}
}
