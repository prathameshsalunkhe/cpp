#include <LPC21xx.H>
int main()
{
PINSEL0=0x5;
U0LCR=0X83;
U0DLL=97;
U0DLM=0;
U0LCR=0X3;
U0THR='R';
while((U0LSR>>5&1)==0);
}
