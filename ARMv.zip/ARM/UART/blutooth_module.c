#include <LPC21xx.H>
#include"header.h"
#define LED1 1<<17
#define LED2 1<<18
int main()
{
unsigned int temp;

IODIR0=LED1 | LED2;
IOSET0=LED1 | LED2;
uart0_init(9600);

uart0_tx_string("\r\nBluetooth Is Connected");
uart0_tx_string("\r\na.LED1 ON");
uart0_tx_string("\r\nb.LED1 OFF");
uart0_tx_string("\r\nc.LED2 ON");
uart0_tx_string("\r\nd.LED2 OFF");
uart0_tx_string("\r\n");

while(1)
{
temp=uart0_rx();
uart0_tx(temp);

while((uart0_rx())!=13);

switch(temp)
{
case 'a':IOCLR0=LED1; break;
case 'b':IOSET0=LED1; break;
case 'c':IOCLR0=LED2; break;
case 'd':IOSET0=LED2; break;
default :uart0_tx_string("\r\nInvalid Option");
}
}
}
        