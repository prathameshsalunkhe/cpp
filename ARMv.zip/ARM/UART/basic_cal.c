#include <LPC21xx.H>
#include"header.h"
int main()
{
unsigned int num1,num2,op,result=0;
uart0_init(9600);

while(1)
{
uart0_tx_string("\r\nEnter The Expression");
num1=uart0_rx();
uart0_tx(num1);

op=uart0_rx();
uart0_tx(op);

num2=uart0_rx();
uart0_tx(num2);

num1=num1-48;
num2=num2-48;

while((uart0_rx())!=13);
uart0_tx_string("\r\nResult:");

switch(op)
{
case '+':result=num1 + num2; break;
case '-':result=num1 - num2; break;
case '*':result=num1 * num2; break;
case '/':result=num1 / num2; break;
default :uart0_tx_string("\r\nInvalid Option");
}
uart0_tx(result/10+48);
uart0_tx(result%10+48);

}
}
