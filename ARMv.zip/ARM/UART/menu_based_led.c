#include <LPC21xx.H>
#include"header.h"
#define LED1 1<<17
#define LED2 1<<18
int main()
{
	unsigned int temp;
	IODIR0=LED1 | LED2;
	IOSET0=LED1 | LED2;
	uart0_init(9600);
	
	uart0_tx_string("Enter The Menu Based Option");
	uart0_tx_string("\r\n a.LED1 ON");
	uart0_tx_string("\r\n b.LED1 OFF");
	uart0_tx_string("\r\n c.LED2 ON");
	uart0_tx_string("\r\n d.LED2 OFF");
	
	while(1)
	{
		//loopback
		temp=uart0_rx();
		uart0_tx(temp);
		while((uart0_rx())!=13);//waiting for press enter key

		switch(temp)
		{
			case 'a':IOCLR0=LED1;break;
			case 'b':IOSET0=LED1;break;
			case 'c':IOCLR0=LED2;break;
			case 'd':IOSET0=LED2;break;
			default :uart0_tx_string("\r\nInvalid Option");
		}
	}
}
