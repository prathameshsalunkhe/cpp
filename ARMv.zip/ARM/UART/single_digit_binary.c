#include <LPC21xx.H>
#include"header.h"
int main()
{
	unsigned int temp;
	uart0_init(9600);
	while(1)
	{
		uart0_tx_string("\r\nEnter Single Digit Number");
		//loopback
		temp=uart0_rx();
		uart0_tx(temp);
		if((uart0_rx())!=13)
		{
			temp=temp-48*10;
		}
		else
		{
			temp=temp-48;
			uart0_tx_string("\r\nEnter Single Digit Number");
		}
			uart0_binary(temp);
	}
}
