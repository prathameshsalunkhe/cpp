#include <LPC21xx.H>
#include"header.h"
int main()
{
	unsigned int temp;
	uart0_init(9600);
	while(1)
	{
		uart0_tx_string("\r\nEnter The Character");
		//loopback
		temp=uart0_rx();
		uart0_tx(temp);

		while((uart0_rx())!=13);
		uart0_tx_string("\r\nThe Ascii Value Are: ");
		uart0_tx(temp/100+48);
		uart0_tx((temp/10)%10+48);
		uart0_tx(temp%10+48);
	}
}
