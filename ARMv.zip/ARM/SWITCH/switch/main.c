#include <LPC21xx.H>
//#include"header.h"
#define LED 7
#define SW ((IOPIN0>>15)&1)
main()
{
int c=0;
IODIR0=LED;
IOSET0=LED;
while(1)
{
if(SW==0)
{
while(SW==0);
c++;
}
if(c%2==0)
IOCLR0=LED;
else
IOSET0=LED;
}
}
