#include <LPC21xx.H>
#include"header.h"
//#define LED 7<<17
#define SW ((IOPIN0>>14)&1)
main()
{
int c=0,i;
IODIR0=7<<0;
IOSET0=7<<0;
while(1)
{
	if(SW==0)
	{	IOSET0=7;
		while(SW==0);
		c++;
		//i^=1;
		//if(i)
			IOCLR0=c;
			//delay_ms(200);
		//else
		//	IOSET0=c;
			//delay_ms(200);
	}
	if(c==7)
	c=0;
}
}
