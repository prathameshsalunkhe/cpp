#include<stdio.h>
void main()
{
	int i,j,k,n,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0,n=1;j<=i;j++,n++)
			printf("%d",n);
		for(k=0;k<(r*2-2)-(2*i);k++)
			printf(" ");
		for(j=0,n=1+i;j<=i;j++,n--)
			printf("%d",n);
		printf("\n");
	}
	printf("\n");
}
