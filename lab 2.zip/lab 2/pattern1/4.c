#include<stdio.h>
void main()
{
int i,j,r,n;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(j=0,n=0;j<=i;j++)
{

