#include<stdio.h>
void main()
{
char ch=491;
printf("%c\n",ch);
}
