#include<stdio.h>
void main()
{
char num=15,r;

r=num>>5&1;
printf("r=%d\n",r);

r=num&1<<5;
printf("r=%d\n",r);
}
