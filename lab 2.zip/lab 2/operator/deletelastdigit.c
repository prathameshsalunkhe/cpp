#include<stdio.h>
void main()
{
int num;
printf("Enter The Number...\n");
scanf("%d",&num);
printf("Before num=%d\n",num);
num=num/10;
printf("After num=%d\n",num);
}
