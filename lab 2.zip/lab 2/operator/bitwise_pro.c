#include<stdio.h>
void main()
{
unsigned char num,pos,r1,r2;
printf("Enter the number and Bit pos:\n");
scanf("%hhd%hhd",&num,&pos);

printf("Before:%hhd\n",num);

/*num=num|1<<pos;
num=num|1<<pos1;
num=num&~(1<<pos);
num=num&~(1<<pos1);
num=num^1<<pos;
num=num^1<<pos1;*/
//num=num>>1;
//num=num>>3;
/*r1=num>>3;
r1=r1<<2;
r2=num<<6;
r2=r2>>6;
num=r1|r2;*/
r1=num>>6;
r1=r1<<5;
r2=num<<6;
r2=r2>>6;
num=r1|r2;

printf("After:%hhd\n",num);
}
