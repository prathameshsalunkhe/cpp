#include<stdio.h>
void main()
{
int i=12;
printf("i=%d\n",i);

i=!i;
printf("i=%d/n",i);
}
