#include<stdio.h>
void main()
{
char num,pos;
printf("Enter The Number and Bit Pos:\n");
scanf("%hhd%hhd",&num,&pos);

printf("Before:%hhd\n",num);

num=num^1<<pos;

printf("After:%hhd\n",num);
}


