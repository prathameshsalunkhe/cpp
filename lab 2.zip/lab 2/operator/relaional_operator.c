#include<stdio.h>
void main()
{
unsigned int i=1;
int j=-1,k;
k=i>j;
//int a=10,b=25,c=30,d;
//d=a<c;
//d=a<b>c;
//printf("d=%d\n",d);
printf("k=%d\n",k);
}

