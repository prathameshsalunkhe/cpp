#include<stdio.h>
void main()
{
int num,r;
printf("Enter The Number....\n");
scanf("%d",&num);

r=num%10;
printf("The Last Digit Of %d is %d\n",num,r);
}
