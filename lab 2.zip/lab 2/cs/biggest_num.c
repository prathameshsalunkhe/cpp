#include<stdio.h>
void main()
{
	int num,num1,num2;
	printf("Enter The 3 Numbers:\n");
	scanf("%d%d%d",&num,&num1,&num2);

	if(num<num1 && num1<num2)
	{
		printf("num2 is Biggest Number\n");
	}
	else if(num<num1 && num1>num2)
	{
		printf("num1 is Biggest Number\n");
	}
	else if(num>num1 && num1>num2)
	{
		printf("num is Biggest Number\n");
	}
}

