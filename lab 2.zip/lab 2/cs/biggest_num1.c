#include<stdio.h>
void main()
{
int num,num1,num2,result;
printf("Enter The 3 Numbers:\n");
scanf("%d%d%d",&num,&num1,&num2);

result=num>num1 ? num>num2 ? printf("Num is Bigger Number") : printf("Num2 is Bigger Number") : num1>num2 ?printf("Num1 is Bigger Number") : printf("Num2 is Bigger Number") ;
}
