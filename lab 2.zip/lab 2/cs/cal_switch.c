#include<stdio.h>
void main()
{
int num,num1,op,ans;
printf("Enter The Numbers:\n");
scanf("%d%d",&num,&num1);

printf("Enter The Option\n1)Add +\n2)Sub -\n3)Mul *\n4)Div /\n");
scanf("%d",&op);

switch(op)
{
case 1: ans=num+num1;
        printf("%d\n",ans);
	break;
case 2: ans=num-num1;
        printf("%d\n",ans);
	break;
case 3: ans=num*num1;
        printf("%d\n",ans);
	break;
case 4: ans=num/num1;
        printf("%d\n",ans);
	break;
default:printf("Unknown Option\n");
}
}
