#include<stdio.h>
void main()
{
int num,k,mul,num1;
printf("Enter The Starting Number and Ending Number:\n");
scanf("%d%d",&num,&num1);
printf("Multiplication Table Of %d to %d is:\n",num,num1);

for(num;num<=num1;num++)
{
for(k=1;k<=10;k++)
{
mul=num*k;
printf("%d ",mul);
}
printf("\n");
}
}
