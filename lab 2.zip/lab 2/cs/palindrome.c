#include<stdio.h>
void main()
{
int num,num1,rev,temp,a;
printf("Enter The Starting And Ending Number:\n");
scanf("%d%d",&num,&num1);

for(num;num<=num1;num++)
{
for(temp=num,rev=0;temp;temp/=10)
{
a=temp%10;
rev=a+rev*10;
}
if(rev==num)
printf("%d ",num);
}
}
