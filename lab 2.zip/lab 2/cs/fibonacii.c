#include<stdio.h>
void main()
{
int a=0,b=1,nxt=0,num=50;
printf("Fibonacci Series betn %d to %d is:\n",a,num);
while(nxt <= num)
{
  a=b;
  b=nxt;
  nxt=a+b;
  printf("%d ",nxt);
}
}


