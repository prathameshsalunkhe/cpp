#include<stdio.h>
void main()
{
	int num,c,i,d;

		printf("enter num and count \n");
	scanf("%d %d",&num,&c);

	for(d=0;d<c;num++)
	{
		for(i=2;i<num;i++)
		{
			if(num%i==0)
				break;
		}
		if(num==i)
		{
			printf("%d\n",num);
			d++;
			}
	}
}
