#include<stdio.h>
void main()
{
int num,a,pos;
printf("Enter The Number:\n");
scanf("%d",&num);
a=~num;
for(pos=31;pos>=0;pos--)
{
printf("%d",a>>pos&1);
if(pos%8==0)
printf(" | ");
}
printf("\n");
printf("decimal=%d\n octal=%o\n hexa=%x\n",a,a,a);
}
