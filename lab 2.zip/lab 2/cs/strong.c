#include<stdio.h>
void main()
{
int num,fact,a,temp,sum,i;
printf("Enter The Number:\n");
scanf("%d",&num);

for(temp=num,sum=0;temp;temp/=10)
{
a=temp%10;
for(i=1,fact=1;i<=a;i++)
{
fact*=i;
}
sum+=fact;
}
if(sum==num)
printf("Strong Number...\n");
else
printf("Not Strong Number...\n");
}

