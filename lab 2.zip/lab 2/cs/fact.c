#include<stdio.h>
void main()
{
int num,i,fact;
printf("Enter The Number:\n");
scanf("%d",&num);

for(i=1,fact=1;i<=num;i++)
fact*=i;
printf("Factorial of %d is:%d\n",num,fact);
}
