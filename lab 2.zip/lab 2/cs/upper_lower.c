#include<stdio.h>
void main()
{
char ch;
printf("Enter The Character:\n");
scanf("%c",&ch);

if(ch>='a' && ch<='z')
{
ch-=32;
printf("Converted character:%c",ch);
}
else if(ch>='A' && ch<='Z')
{
ch+=32;
printf("Converted character:%c",ch);
}
}

