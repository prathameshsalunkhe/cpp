#include<stdio.h>
void main()
{
int num,pow,i,power=1;
printf("Enter The Number & power:\n");
scanf("%d%d",&num,&pow);

for(i=1;i<=pow;i++)
{
power*=num;
}
printf("Power:%d\n",power);
}

