#include<stdio.h>
void main()
{
int num,num1,num2,pos1;
printf("Enter The Number:\n");
scanf("%d",&num);
for(pos1=31;pos1>=0;pos1--)
{
printf("%d",num>>pos1&1);
if(pos1%8==0)
printf(" | ");
}
printf("\n");

num1=num>>28;
num1=num1<<28;
num2=num>>5;
num2=num2<<5;
num=num1|num2;

for(pos1=31;pos1>=0;pos1--)
{
printf("%d",num>>pos1&1);
if(pos1%8==0)
printf(" | ");
}
}
