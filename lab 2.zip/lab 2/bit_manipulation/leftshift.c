#include<stdio.h>
void main()
{
int num,pos,n,a,b;
printf("Enter The Number & no of rotation:\n");
scanf("%d%d",&num,&n);
printf("Before swap:\n");

for(pos=31;pos>=0;pos--)
{
printf("%d",num>>pos&1);
if(pos%8==0)
printf(" | ");
}

a=num<<n;
b=num>>32-n;
num=a | b;

printf("\n");
printf("After swap:\n");

for(pos=31;pos>=0;pos--)
{
printf("%d",num>>pos&1);
if(pos%8==0)
printf(" | ");
}
}
