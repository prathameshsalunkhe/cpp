#include<stdio.h>
void main()
{
int num;
printf("Enter The Number:\n");
scanf("%d",&num);

if((num&num-1)==0)
printf("Number is power of 2\n");
else 
printf("Number is Not power of 2\n");
}

