#include<stdio.h>
void main()
{
int num;
printf("Enter The Number:\n");
scanf("%d",&num);

if((num&7)==0)
printf("Given Number is Divisible By 8\n");
else
printf("Given Number is Not Divisible By 8\n");

}
