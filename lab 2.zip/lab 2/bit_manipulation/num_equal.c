#include<stdio.h>
void main()
{
int num,num1;
printf("Enter The two Numbers:\n");
scanf("%d%d",&num,&num1);

if((num^num1)==0)
printf("Equal Numbers\n");
else
printf("Not Equal Numbers\n");
}
