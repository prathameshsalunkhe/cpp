#include<stdio.h>
void main()
{
char ch,r;
printf("Enter The Character:\n");
scanf("%c",&ch);

r=ch^32;

printf("After Conversion:%c %d\n",r,r);
}
