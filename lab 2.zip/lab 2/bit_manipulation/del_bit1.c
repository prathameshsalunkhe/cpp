#include<stdio.h>
void main()
{
int num1,num2,num3;
printf("Enter The Number:\n");
scanf("%d",&num);

for(pos=31;pos>=0;pos--)
{
p
