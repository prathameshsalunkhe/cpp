#include<stdio.h>
void main()
{
int num,pos,pos1;
printf("Enter The Number And Bit position:\n");
scanf("%d%d",&num,&pos);

for(pos1=31;pos1>=0;pos1--)
{
printf("%d",num>>pos1&1);
if(pos1%8==0)
printf(" | ");
}
printf("\n");
num=num^1<<pos;
for(pos1=31;pos1>=0;pos1--)
{
printf("%d",num>>pos1&1);
if(pos1%8==0)
printf(" | ");
}
printf("\n");

}
