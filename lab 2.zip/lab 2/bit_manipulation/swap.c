#include<stdio.h>
void main()
{
int num1,num2;
printf("Enter The 2 Numbers:\n");
scanf("%d%d",&num1,&num2);
printf("Brfore swap: num1=%d num2=%d\n ",num1,num2);

num1^=num2^=num1^=num2;

printf("After swap: num1=%d num2=%d\n ",num1,num2);

}
