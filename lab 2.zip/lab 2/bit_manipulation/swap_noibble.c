#include<stdio.h>
void main()
{
int num,pos,i,j,m,n;
printf("Enter The Number:\n");
scanf("%d",&num);
printf("Before swap:\n");

for(pos=31;pos>=0;pos--)
{
printf("%d",num>>pos&1);
if(pos%8==0)
printf(" | ");
}

for(i=0,j=28;i<4;i++,j++)
{
m=num>>i&1;
n=num>>j&1;
if(m!=n)
{
num=num^1<<i;
num=num^1<<j;
}
}
printf("After swap:\n");

for(pos=31;pos>=0;pos--)
{
printf("%d",num>>pos&1);
if(pos%8==0)
printf(" | ");
}
}
