#include<stdio.h>
void main()
{
int num;
printf("Enter The Number:\n");
scanf("%d",&num);

if(num&1==1)
printf("Odd Number\n");
else
printf("Even Number\n");
}
