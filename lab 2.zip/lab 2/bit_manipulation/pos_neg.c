#include<stdio.h>
void main()
{
int num;
printf("Enter The Number:\n");
scanf("%d",&num);

if((num>>31&1)==1)
printf("Negative Number\n");
else
printf("Positive Number\n");
}
