#include<stdio.h>
void main()
{
int num=0x1234,r,r1,r2;
printf("Before Swap:%x\n",num);

r1=num&0x00ff;
r1=r1<<8;

r2=num&0xff00;
r2=r2>>8;

r=r1|r2;

printf("After Swap:%x\n",r);
}

