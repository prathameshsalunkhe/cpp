#include<stdio.h>
int var=6;
int main(void)
{
	int var=18;
	printf("%d\n",var);
	return 0;
}
