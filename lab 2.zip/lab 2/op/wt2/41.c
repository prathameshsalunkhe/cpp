#include<stdio.h>
void main()
{ 
	char x = 0xFF;
	unsigned int y; 
	int z;
	y = x;
	z = x;
	printf("%x %x", y, z); 
}
