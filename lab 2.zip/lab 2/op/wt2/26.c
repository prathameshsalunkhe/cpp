#include<stdio.h>
void main( )
{
int a = -3;
a = -a -a + !a;
printf("%d",a);
}
