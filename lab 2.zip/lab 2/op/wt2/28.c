#include<stdio.h>
void main() 
{
extern i;
printf("%d",i);
{
int i=20;
printf("%d",i);
}
}
