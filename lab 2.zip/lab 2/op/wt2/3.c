#include<stdio.h>
	printf("%d\n",x);
void main() 
{ 
	int x = 3, counter = 0 ; 
	while ( (x -1 ) ) 
	{ 
		++counter ;
		x -- ;
	} 
	printf("%d ",counter); 
}
