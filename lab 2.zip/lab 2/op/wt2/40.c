#include<stdio.h>
void main()
{
	int a;
	a = (1,45,012);
	printf("%d", a);
}
