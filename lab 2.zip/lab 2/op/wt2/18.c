#include<stdio.h>
void main()
{
	extern int i;
	i=20; 
	printf("%d",sizeof(i));
}

