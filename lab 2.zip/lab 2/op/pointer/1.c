#include <stdio.h> 
     int main() 
     {
	int *p = 10;
	printf(" %u\n", (unsigned int)p);
            printf(" %d\n" ,  p+10 );
	printf("%d\n",  *p);
     }

