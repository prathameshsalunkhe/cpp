#include<stdio.h>
int main(void)
{
	int i=9;
	if(i==9)
	{
		int i=25;
	}
	printf("i=%d\n",i);
	return 0;
}
