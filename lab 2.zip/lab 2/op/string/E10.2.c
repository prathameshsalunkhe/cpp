#include<stdio.h>
int main(void)
{
	char *str;
	printf("Enter a string : ");
	gets(str);
	printf("String is %s\n",str);
	return 0;
}
