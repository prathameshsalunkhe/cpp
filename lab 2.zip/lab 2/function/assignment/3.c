#include<stdio.h>
void del_fun(int *,int);
void main()
{
	int a[6],ele,i;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Elements:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	del_fun(a,ele);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);

}

void del_fun(int *a,int ele)
{
	int i,rev,rev1,b,c;
	for(i=0;i<ele;i++)
	{
		for(rev=0;a[i];a[i]/=10)
		{
			b=a[i]%10;
			rev=rev*10+b;
		}
		rev/=10;
		for(rev1=0;rev;rev/=10)
		{
			c=rev%10;
			rev1=rev1*10+c;
		}
		a[i]=rev1;
	}
}
