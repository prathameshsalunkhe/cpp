#include<stdio.h>
void sum_fun(int *,int *,int);
void main()
{
	int a[6],b[6],ele,i;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	sum_fun(a,b,ele);

	for(i=0;i<ele;i++)
		printf("%d ",b[i]);

}

void sum_fun(int *a,int *b,int ele)
{
	int i,sum,c;
	for(i=0;i<ele;i++)
	{
		for(sum=0;a[i];a[i]/=10)
		{
			c=a[i]%10;
			sum+=c;
		}
		b[i]=sum;
	}
}
