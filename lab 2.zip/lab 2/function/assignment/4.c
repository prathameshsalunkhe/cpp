#include<stdio.h>
int strong_fun(int *,int);
int armstrong_fun(int *,int);
void main()
{
	int a[6],ele,i,c,d;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Elements:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	c=strong_fun(a,ele);
	d=armstrong_fun(a,ele);

	printf("Strong number count:%d\n",c);
	printf("Armstrong number count:%d\n",d);

}

int strong_fun(int *a,int ele)
{
	int i,fact,mul,b,sum,c,t;
	for(i=0,c=0;i<ele;i++)
	{
		for(sum=0,t=a[i];t;t/=10)
		{
			b=t%10;
			for(fact=1,mul=1;fact<=b;fact++)
				mul*=fact;
				sum+=mul;
		}
		if(sum==a[i])
			c++;
	}
	return c;
}

int armstrong_fun(int *a,int ele)
{
	int i,c,d,t,sum,mul,b,c1;
	for(i=0,c1=0;i<ele;i++)
	{
		for(t=a[i],c=0;t;t/=10,c++);
		for(t=a[i],sum=0;t;t/=10)
		{
			b=t%10;
			for(d=0,mul=1;d<c;d++)
				mul*=b;
			sum+=mul;
		}
	if(sum==a[i])
		c1++;
	}
	return c1;
}





