#include<stdio.h>
void rev_word_fun(char *);
int count_word_fun(char *);
void main()
{
	char s[50];
	int c;
	printf("Enter The String:\n");
	scanf("%[^\n]",s);

	rev_word_fun(s);
	printf("%s\n",s);
	c=count_word_fun(s);
	printf("Word Count:%d\n",c);
}

void rev_word_fun(char *s)
{
	int i,c,j,k;
	char t;
	for(i=0;s[i];i=c)
	{
		for(c=i;s[c]!=' '&&s[c]!='\0';c++);
		for(k=i,j=c-1;k<j;k++,j--)
		{
			t=s[k];
			s[k]=s[j];
			s[j]=t;
		}
		c++;
	}
}

int count_word_fun(char *s)
{
	int i,c,c1,j,k;
	for(i=0,c1=0;s[i];i=c)
	{
		for(c=i;s[c]!=' '&&s[c]!='\0';c++);
		for(j=i;j<c;j++)
		{
			if(s[j]>='0'&&s[j]<='9')
			{
				c1++;
				break;
			}
		}
		c++;
	}
	return c1;
}
