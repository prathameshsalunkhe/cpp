#include<stdio.h>
void print_string(const char *);
void main()
{
char s[20];
printf("Enter The String:\n");
scanf("%[^\n]",s);
print_string(s);
}

void print_string(const char *s)
{
while(*s)
printf("%c ",*s++);
printf("\n");
}
