#include<stdio.h>
#include<string.h>
void main()
{
char m[100],s[20];
printf("Enter The Main &sub string:\n");
scanf("%s%s",m,s);

printf("Before: m=%s\n",m);
int len;
char *p,*q;
p=m;

while(p=strstr(p,s))
{
len=strlen(s);
q=p+len;
strcpy(p,q);
}
printf("Before: m=%s\n",m);
}
