#include<stdio.h>
int print(int);
void main()
{
int num;
printf("Enter the number:\n");
scanf("%d",&num);
print(num);
printf("\n");
}

int print(int n)
{
int pos;
for(pos=31;pos>=0;pos--)
printf("%d",n>>pos&1);
}

