#include<stdio.h>
void bubble_sort(int *,int);
void print(const int *,int);
void main()
{
	int a[5],ele,i;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	print(a,ele);
	bubble_sort(a,ele);
	print(a,ele);
}

void bubble_sort(int *a,int ele)
{
	int i,j,t;
	for(i=0;i<ele-1;i++)
	{
		for(j=0;j<ele-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
}

void print(const int *a,int ele)
{
	int i;
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}

