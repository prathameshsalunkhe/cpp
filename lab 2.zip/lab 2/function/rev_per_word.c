#include<stdio.h>
void my_strrev1(char *,char *);
void main()
{
	char s[50];
	printf("Enter The String:\n");
	scanf("%[^\n]",s);

	printf("%s\n",s);
	my_strrev1(s+7,s+11);
	printf("%s",s);
}

void my_strrev1(char *p,char *q)
{
	char t;
	while(p<q)
	{
		t=*p;
		*p=*q;
		*q=t;
		p++;
		q--;
	}
}

