#include<stdio.h>
void main()
{
int num,i=2;
printf("Enter The Number:\n");
scanf("%d",&num);

while(i<num)
{
if(num%i==0)
break;
i++;
}
if(num==i)
printf("Prime Number\n");
else
printf("Not Prime Number\n");
}
