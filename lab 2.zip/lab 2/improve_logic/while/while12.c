#include<stdio.h>
void main()
{
int num,a,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);

num%=1000;
while(num)
{
a=num%10;
sum+=a;
num/=10;
}
printf("Sum=%d\n",sum);
}
