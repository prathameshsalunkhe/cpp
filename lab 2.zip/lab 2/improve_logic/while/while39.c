#include<stdio.h>
void main()
{
int num,a,rev=0;
printf("Enter The Number:\n");
scanf("%d",&num);

while(num)
{
a=num%10;
rev=a+rev*10;
num/=10;
}
printf("Rev=%d\n",rev);
}
