#include<stdio.h>
void main()
{
int num,c=0,a;
printf("Enter The Number:\n");
scanf("%d",&num);

while(num)
{
a=num%10;
if(a%2==0 && a>=1 && a<=7)
c++;
num/=10;
}
printf("Count of digits=%d\n",c);
}
