#include<stdio.h>
void main()
{
int num=3,c=0,mul=1;

while(c<4)
{
mul*=num;
c++;
}
printf("mul=%d\n",mul);
}
