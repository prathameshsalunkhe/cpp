#include<stdio.h>
void main()
{
int num,i=1,mul=1;
printf("Enter The Number:\n");
scanf("%d",&num);

while(i<=num)
{
mul*=i;
i++;
}
printf("Factorial of %d is:%d\n",num,mul);
}
