#include<stdio.h>
void main()
{
int num=-19,k=6;

while(k>0)
{
num+=k;
printf("%d ",num);
k--;
}
}
