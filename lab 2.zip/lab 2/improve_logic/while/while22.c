#include<stdio.h>
void main()
{
int num,a,b,c=0,sum=0,temp,rev=0;
printf("Enter The Number:\n");
scanf("%d",&num);

temp=num;
while(temp)
{
b=temp%10;
rev=b+rev*10;
temp/=10;
}

while(rev)
{
a=rev%10;
if(a%2!=0 && c<3)
{
sum+=a;
c++;
}
rev/=10;
}
printf("Sum=%d\n",sum);
}
