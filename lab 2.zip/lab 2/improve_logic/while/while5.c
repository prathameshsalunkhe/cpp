#include<stdio.h>
void main()
{
int num,a,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);

while(num)
{
a=num%10;
if(a>=3 && a<=8)
sum+=a;
num/=10;
}
printf("Sum=%d\n",sum);
}
