#include<stdio.h>
void main()
{
int num,a,rev=0,temp;
printf("Enter The Number:\n");
scanf("%d",&num);

temp=num;
while(temp)
{
a=temp%10;
if(a%2!=0)
rev=a+rev*10;
temp/=10;
}
printf("rev=%d",rev);
}
