#include<stdio.h>
void main()
{
int num,i=1,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);

while(i<num)
{
if(num%i==0)
sum+=i;
i++;
}
if(sum==num)
printf("Perfect Number\n");
else
printf("Not Perfect Number\n");
}
