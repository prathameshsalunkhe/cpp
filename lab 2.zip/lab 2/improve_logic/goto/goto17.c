#include<stdio.h>
void main()
{
	int pos=7;
	char ch;
	printf("Enter The Char:\n");
	scanf("%c",&ch);

L1:
	if(pos>=0)
	{
		printf("%d",(ch>>pos)&1);
		pos--;
		goto L1;
	}
	printf("\n");
}


