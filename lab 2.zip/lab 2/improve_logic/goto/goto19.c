#include<stdio.h>
void main()
{
	int num,pos,i=0,j=8,m,n;
	printf("Enter The Number:\n");
	scanf("%d",&num);
		printf("Before:\n");
		
 pos=31;
L1:
	if(pos>=0)
	{
		printf("%d",num>>pos&1);
		
		if(pos%4==0)
			printf(" | ");
		pos--;	
		goto L1;
	}
	printf("\n");

L2:
	if(i<=3)
	{
		m=num>>i&1;
		n=num>>j&1;
		if(m!=n)
		{
			num=num^1<<i;
			num=num^1<<j;
		}
		i++;
		j++;
		goto L2;
	}
pos=31;
		printf("After:\n");
L3:
	if(pos>=0)
	{
		printf("%d",num>>pos&1);
	
		if(pos%4==0)
			printf(" | ");
			pos--;
		goto L3;
	}
	printf("\n");
}
