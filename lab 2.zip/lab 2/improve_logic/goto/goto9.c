#include<stdio.h>
void main()
{
	int num,a,sum=0;
	printf("Enter The Number:\n");
	scanf("%d",&num);

L1:
	if(num>0)
	{
		a=num%10;
		sum+=a;
		num=num/10;
		goto L1;
	}
	printf("sum=%d\n",sum);
}
