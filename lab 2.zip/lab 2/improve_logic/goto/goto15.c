#include<stdio.h>
void main()
{
	int n=1,nxt;

L1:
	if(n<=6)
	{
		nxt=(n*n*n)+1;
		printf("%d ",nxt);
		n++;
		goto L1;

	}
}
