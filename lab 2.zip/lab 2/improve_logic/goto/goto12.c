#include<stdio.h>
void main()
{
	int i,j,c=0;
	printf("Enter The Numbers:\n");
	scanf("%d%d",&i,&j);
L1:
	if(i<=j)
	{
		if(i%2!=0)
		{
			c++;
			if(c%2!=0)
				printf("%d ",i);
			i++;
		}
		else
			i++;
		goto L1;
	}
}


