#include<stdio.h>
void main()
{
int num,pow,c=0,mul=1;
printf("Enter the Number and power:\n");
scanf("%d%d",&num,&pow);

L1:
if(num>0)
{
mul*=num;
c++;
if(c<pow)
goto L1;
}
printf("Result=%d\n",mul);

}


