#include<stdio.h>
void main()
{
	int num,a,rev=0;
	printf("Enter The Number:\n");
	scanf("%d",&num);

L1:
	if(num>0)
	{
		a=num%10;
		rev=a+(rev*10);
		num=num/10;
		goto L1;
	}
	printf("Reverse=%d\n",rev);
}
