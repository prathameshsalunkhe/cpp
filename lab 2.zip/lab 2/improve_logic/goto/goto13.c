#include<stdio.h>
void main()
{
	int a,b,c=0,i=0;
	printf("Enter Starting Number & count:\n");
	scanf("%d%d",&a,&b);

L1:
	if(a>0)
	{
		a+=i;
		i++;
		printf("%d ",a);
		if(i<b)
			goto L1;
	}
}

