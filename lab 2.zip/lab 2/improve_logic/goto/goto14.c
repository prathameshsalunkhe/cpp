#include<stdio.h>
void main()
{
	int a,b;
	printf("Enter Starting Number & count:\n");
	scanf("%d%d",&a,&b);
	

L1:
	if(b>=0)
	{
		printf("%d ",a);
		a+=b;
		b--;
		goto L1;
	}
}

