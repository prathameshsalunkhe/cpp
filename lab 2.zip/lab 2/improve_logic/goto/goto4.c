#include<stdio.h>
void main()
{
int num,i=1,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);
printf("Factors of %d are: ",num);
L1:
if(num>0)
{
   if(num%i==0)
   {
      printf("%d ",i);
      i++;
      c++;
    }
    else
      i++;
      if(i<=num)
      goto L1;
   }
 printf("\n");
 printf("c=%d",c);
 }
		
