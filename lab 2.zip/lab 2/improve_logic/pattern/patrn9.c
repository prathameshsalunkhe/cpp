/* 6 4 2
   4 2 
   2       */

///////////////////////////

#include<stdio.h>
void main()
{
int i,j,n;
for(i=0;i<3;i++)
{
for(j=0,n=8-i*2;j<3-i;j++)
{
printf("%d ",n=n-2);
//n=n-2;
}
printf("\n");
}
}
