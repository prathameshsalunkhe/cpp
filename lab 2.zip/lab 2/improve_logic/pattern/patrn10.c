/* 1  
   3 1 
   5 3 1     */

///////////////////////////

#include<stdio.h>
void main()
{
int i,j,n;
for(i=0;i<3;i++)
{
for(j=0,n=3+i*2;j<=i;j++)
{
printf("%d ",n=n-2);
//n=n-2;
}
printf("\n");
}
}
