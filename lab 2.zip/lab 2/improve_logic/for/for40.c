#include<stdio.h>
void main()
{
	int num,i,rev,temp;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(rev=0,temp=num;temp;temp/=10)
	{
		i=temp%10;
		rev=i+(rev*10);
	}
	if(rev==num)
	printf("Palindrom Number\n");
	else
	printf("Not Palindrom Number\n");
}
