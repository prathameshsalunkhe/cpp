#include<stdio.h>
void main()
{
	int num,sum,a,c;
	printf("Enter The Number:");
	scanf("%d",&num);

	for(sum=0,c=0;num;num/=10)
	{
		a=num%10;
		if(a%2!=0)
		{
		sum+=a;
		c++;
		if(c==3)
		break;
		}
		
		
	}
	printf("sum=%d",sum);
}

