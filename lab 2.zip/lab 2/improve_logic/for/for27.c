#include<stdio.h>
void main()
{
	int num,temp,a,b,c,d,sum;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(c=0,temp=num;temp;temp/=10)
	{
		a=temp%10;
		c++;
	}
	for(d=0,sum=0;num;num/=10)
	{
		b=num%10;
		d++;
		if(d==1 || d==c)
			sum+=b;
	}

	printf("sum=%d\n",sum);
}
