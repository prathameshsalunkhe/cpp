#include<stdio.h>
void main()
{
	int a,b;
	printf("Enter Starting Number and count:\n");
	scanf("%d%d",&a,&b);

	for( ;b>=0;b--)
	{
		printf("%d ",a);
		a+=b;
	}
}
