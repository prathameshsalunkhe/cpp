#include<stdio.h>
void main()
{
int a,b,i;
printf("Enter Starting Number & count:\n");
scanf("%d%d",&a,&b);

for(i=0;i<b;i++)
{
a+=i;
printf("%d ",a);
}
}
