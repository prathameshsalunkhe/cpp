#include<stdio.h>
void main()
{
	int num,a,rev;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(rev=0,num=num%100;num;num/=10)
	{
		a=num%10;
		rev=a+(rev*10);
	}
	printf("After:%d",rev);
}
