#include<stdio.h>
void main()
{
	int num,c=0;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(num;num;num/=10)
		c++;
	printf("Count of digit:%d",c);
}
