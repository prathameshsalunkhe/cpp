#include<stdio.h>
void main()
{
int n,nxt;

for(n=1;n<=6;n++)
{
nxt=(n*n*n)+1;
printf("%d ",nxt);
}
}
