#include<stdio.h>
void main()
{
int num;
printf("Enter The Number:\n");
scanf("%d",&num);

for(num=num%100;num>10;num/=10);
printf("Second last Digit=%d\n",num);
}
