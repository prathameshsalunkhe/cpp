#include<stdio.h>
void main()
{
	int num,a,c;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(c=0;c<1;num/=10)
	{
		a=num%10;
		if(a%2!=0)
		{
			printf("First Odd digit=%d\n",a);
			c++;
		}
	}
}
