#include<stdio.h>
void main()
{
	int num,i,sum;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(sum=0;num;num/=10)
	{
		i=num%10;
		sum+=i;
	}
	printf("sum=%d\n",sum);
}

