#include<stdio.h>
void main()
{
	int num,fact,i;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(fact=1,i=1;i<=num;i++)
	{
		fact*=i;
	}
	printf("Factorial of %d is:%d\n",num,fact);
}
