/*   1
     2  6
     3  7  10
     4  8  11  13
     5  9  12  14  15    */

////////////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,b=0,num=1,k,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++,num++)
	{
		b=num;
		for(j=0,k=r-1;j<=i;j++,k--)
		{
			printf("%d  ",b);
			b=b+k;
		}
		printf("\n");
	}
}

		
