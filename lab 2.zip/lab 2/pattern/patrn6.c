/*  * * * * * *
    1 3 5 7 9
    * * * *
    1 3 5 
    * *
    1             */

 ////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0;j<r-i;j++)
		{
			if(i%2==0)
				printf("* ");
			else 
				printf("%d ",1+2*j);
		}
		printf("\n");
	}
}
/*
{
	int i,j;

	for(i=0;i<6;i++)
	{
		for(j=0;j<6-i;j++)
		{
			if(i%2==0)
				printf("* ");
			else 
				printf("%d ",1+2*j);
		}
		printf("\n");
	}
}*/
