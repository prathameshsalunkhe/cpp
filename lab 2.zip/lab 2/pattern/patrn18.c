/*              1
             1  4
	  1  4  9
	1 4  9 16
      1 4 9 16 25    */

//////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r,num,l;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-i;k++)
printf("  ");
for(j=0,num=1,l=3;j<=i;j++,l=l+2)
{
printf("%d ",num);
num=num+l;
}
printf("\n");
}
}
