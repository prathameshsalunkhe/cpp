/*   1
     321
     54321
     7654321   */

//////////////////////////

#include<stdio.h>
void main()
{
	int i,j,num,b;

	for(i=0,num=1;i<4;i++,num+=2)
	{
		b=num;
		for(j=0;j<=i*2;j++,b--)
			printf("%d",b);
		printf("\n");
	}
}
