/*    1 2 3 4 *
      1 2 3 * 5
      1 2 * 4 5
      1 * 3 4 5
      * 2 3 4 5   */

/////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,n;

	for(i=0;i<5;i++)
	{
		for(j=0,n=1;j<5;j++){
			if(j==5-i-1)
				printf("* ");
				else
			printf("%d ",n+j);
	}

	printf("\n");

	}

}


