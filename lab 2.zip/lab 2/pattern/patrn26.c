/*        1
        2 3 2
      3 4 5 4 3
    4 5 6 7 6 5 4    */

/////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r,num,m,n;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-i;k++)
printf("  ");
for(j=0,num=i+1;j<=i;j++,num++)
printf("%d ",num);
for(m=0,n=i*2;m<i;m++,n--)
printf("%d ",n);
printf("\n");
}
}
