/*   13579
      3579
       579
        79
	 9   */

//////////////////////////

#include<stdio.h>
void main()
{
	int i,j,k,n=1,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(k=0;k<i;k++)
			printf(" ");
		for(j=0;j<r-i;j++)
		{
			printf("%d",n+2*j);
		}
		printf("\n");
		n=n+2;
	}
}
/*
{
	int i,j,k,n=1;

	for(i=0;i<5;i++)
	{
		for(k=0;k<i;k++)
			printf(" ");
		for(j=0;j<5-i;j++)
		{
			printf("%d",n+2*j);
		}
		printf("\n");
		n=n+2;
	}
}*/
