/*    E D C B A
      * D C B A
      * * C B A
      * * * B A
      * * * * A    */

////////////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k;
char ch;

for(i=0;i<5;i++)
{
for(k=0;k<i;k++)
printf("* ");
for(j=0,ch='E'-i;j<5-i;j++,ch--)
printf("%c ",ch);
printf("\n");
}
}















/*for(i=0;i<5;i++)
{
for(j=0,ch='A';j<5;j++)
{
ch='A'+4-j;
if(j<i)
printf("* ");
else
printf("%c ",ch);
}
printf("\n");
}
}*/
