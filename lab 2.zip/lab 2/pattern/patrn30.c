/*       A
        A B
       A B C
      A B C D
     A B C D E
      A B C D
       A B C
        A B
	 A        */

//////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r;
char ch;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-i-1;k++)
printf(" ");
for(j=0,ch='A';j<=i;j++)
printf("%c ",ch++);
printf("\n");
}
for(i=0;i<r-1;i++)
{
for(k=0;k<=i;k++)
printf(" ");
for(j=0,ch='A';j<r-i-1;j++)
printf("%c ",ch++);
printf("\n");
}
}

