/*            A
            B B
	  C C C
	D D D D
      E E E E E     */

///////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r;
char ch;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0,ch='A';i<r;i++,ch++)
{
for(k=0;k<r-i;k++)
printf("  ");
for(j=0;j<=i;j++)
printf("%c ",ch);
printf("\n");
}
}
