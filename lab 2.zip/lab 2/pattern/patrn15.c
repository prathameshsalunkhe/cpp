/*   1
     1 2
     1 2 4
     1 2 4 7
     1 2 4 7 11  */

///////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,num;

for(i=0;i<5;i++)
{
num=1;
for(j=0,k=1;j<=i;j++,k++)
{
printf("%d ",num);
num=num+k;
}
printf("\n");
}
}
