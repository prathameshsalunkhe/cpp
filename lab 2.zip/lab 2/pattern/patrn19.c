/*          Z
          Z Y
	Z Y X
      Z Y X W
    Z Y X W V      */

///////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r;
char ch;
printf("Enter The Number OF Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-i;k++)
printf("  ");
for(j=0,ch='Z';j<=i;j++)
{
printf("%c ",ch);
ch=ch-1;
}
printf("\n");
}
}
	
