/*    F E D C B A
       E D C B A
        D C B A
	 C B A
	  B A
	   A          */

//////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r;
char ch;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<i;k++)
printf(" ");
for(j=0,ch='A'+r-1-i;j<r-i;j++,ch--)
printf("%c ",ch);
printf("\n");
}
}
