/*    P Q R S T U V
        P Q R S T
	  P Q R
	    P         */

////////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r;
char ch;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<i;k++)
printf("  ");
for(j=0,ch='P';j<7-(2*i);j++)
{
printf(" %c",ch);
ch=ch+1;
}
printf("\n");
}
}
