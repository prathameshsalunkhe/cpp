/*  2
    2 4
    2 4 6
    2 4 6 8
    2 4 6 8 10  */

//////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,r;
	printf("Enter The Number of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0;j<=i;j++)
			printf("%d ",2+2*j);
		printf("\n");
	}
}
/*
{
	int i,j;

	for(i=0;i<5;i++)
	{
		for(j=0;j<=i;j++)
			printf("%d ",2+2*j);
		printf("\n");
	}
}*/
