/*        A
        C B A
      E D C B A
    G F E D C B A
  I H G F E D C B A     */

//////////////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r,l;
char ch;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-i;k++)
printf("  ");
for(j=0,ch='A'+2*i;j<1+2*i;j++,ch--)
printf("%c ",ch);
//for(l=0,ch='A'+i-1;l<i;l++,ch--)
//printf("%c ",ch);
printf("\n");
}
}
