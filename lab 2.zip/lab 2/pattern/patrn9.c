/*          E
          1 2
        C D E
      1 2 3 4
    A B C D E   */

////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,k,n,r;
	char ch;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
       //	ch='A'+4-i;
		for(k=0;k<r-i;k++)
			printf("  ");
		for(j=0,n=1,ch='A'+r-1-i;j<=i;j++)
		{
			if(i%2==0)
			{
				printf("%c ",ch++);
			}
			else
			{
				printf("%d ",n);
				n=n+1;
			}
		}
		printf("\n");
	}
}
