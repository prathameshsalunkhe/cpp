/*     *
     * * *
   * * * * *
 * * * * * * *    */

/////////////////////////

#include<stdio.h>
void main()
{
int i,j,k,r;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-i-1;k++)
printf(" ");
for(j=0;j<=2*i;j++)
printf("*");
printf("\n");
}
}
