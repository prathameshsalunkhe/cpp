/*         #
         A B
       # # #
     A B C D
   # # # # #   */

///////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,k;
	char ch;

	for(i=0;i<5;i++)
	{
		for(k=0;k<5-i;k++)
			printf("  ");
		for(j=0,ch='A';j<=i;j++)
		{
			if(i%2!=0)
			{
				printf(" %c",ch);
				ch=ch+1;
			}
			else
				printf(" #");
		}
		printf("\n");
	}
}
