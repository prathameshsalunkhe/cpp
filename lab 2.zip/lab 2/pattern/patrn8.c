/*   5
     * *
     5 4 3
     * * * *
     5 4 3 2 1   */

////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,r,n;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0,n=r;j<=i;j++)
		{
			if(i%2==0)
			{
				printf("%d ",n);
				n=n-1;
			}
			else
				printf("* ");
		}
		printf("\n");
	}
}

