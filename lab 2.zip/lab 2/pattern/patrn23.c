/*   4 3 2 1
       A B C
         2 1
	   A     */

/////////////////////////

#include<stdio.h>
void main()
{
	int i,j,k,r,num;
	char ch;
	printf("Enter The Number Of Rows:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(k=0;k<i;k++)
			printf("  ");
		for(j=0,num=r-i,ch='A';j<r-i;j++,num--,ch++)
		{
			if(i%2==0)
				printf("%d ",num);
			else
				printf("%c ",ch);
		}
		printf("\n");
	}
}
