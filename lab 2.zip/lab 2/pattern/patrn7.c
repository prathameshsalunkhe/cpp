/*   A 1 B 2 C
     A 1 B 2
     A 1 B
     A 1
     A            */

//////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,n,r;
	char ch;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0,ch='A',n=1;j<r-i;j++)
		{
			if(j%2==0)
			{
				printf("%c ",ch);
				ch=ch+1;
				}
				else
				{
					printf("%d ",n);
				n=n+1;
				}
		}
			printf("\n");
	}
}
/*
{
	int i,j,n;
	char ch;

	for(i=0;i<5;i++)
	{
		for(j=0,ch='A',n=1;j<5-i;j++)
		{
			if(j%2==0)
			{
				printf("%c ",ch);
				ch=ch+1;
				}
				else
				{
					printf("%d ",n);
				n=n+1;
				}
		}
			printf("\n");
	}
}*/
