/*   1 2 4 7 11 16
     1 2 4 7 11
     1 2 4 7
     1 2 4
     1 2
     1                */

 //////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,k,r,num,b;
	printf("Enter The Number Of Rows:\n");
	scanf("%d",&r);

	for(i=0,num=1;i<r;i++)
	{
		b=num;
		for(j=0,k=1;j<r-i;j++,k++)
		{
			printf("%d ",b);
			b=b+k;
		}
		printf("\n");
	}
}



