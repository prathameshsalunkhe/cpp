/*  1
    1 3
    1 3 5 
    1 3 5 7   */

 /////////////////////////

#include<stdio.h>
void main()
{
	int i,j,r;
	printf("Enter The Numbers of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0;j<=i;j++)
			printf("%d ",1+2*j);
		printf("\n");
	}
}
/*
{
	int i,j;

	for(i=0;i<4;i++)
	{
		for(j=0;j<=i;j++)
			printf("%d ",1+2*j);
		printf("\n");
	}
}*/
