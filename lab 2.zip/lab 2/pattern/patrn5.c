/*  A
    A *
    A * C
    A * C *
    A * C * E   */

////////////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,r;
	char ch;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0,ch='A';j<=i;j++,ch++)
		{
			if(j%2==0)
				printf("%c ",ch);
			else
				printf("* ");
		}
		printf("\n");
	}
}
/*
{
	int i,j;
	char ch;

	for(i=0;i<5;i++)
	{
		for(j=0,ch='A';j<=i;j++,ch++)
		{
			if(j%2==0)
				printf("%c ",ch);
			else
				printf("* ");
		}
		printf("\n");
	}
}*/
