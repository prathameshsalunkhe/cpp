/*     * * * * *
        4 3 2 1
	 * * *
	  2 1
	   *       */

///////////////////////////////

#include<stdio.h>
void main()
{
	int i,j,k,r,num;
	printf("Enter The Number Of Rows:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(k=0;k<i;k++)
			printf(" ");
		for(j=0,num=r-i;j<r-i;j++)
		{

			if(i%2==0)
				printf(" *");
			else 
				printf(" %d",num);
			num=num-1;
		}
		printf("\n");
	}
}
