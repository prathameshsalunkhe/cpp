#include<stdio.h>
void main()
{
int a[6],i,j,ele,t;
ele=sizeof(a)/sizeof(a[0]);
printf("Enter The Element:\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

printf("Before:");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");

for(i=0;i<ele/2;i++)
{
t=a[i];
a[i]=a[i+ele/2];
a[i+ele/2]=t;
}

/*for(i=0,j=ele/2;i<ele/2;i++,j++)
{
t=a[i];
a[i]=a[j];
a[j]=t;
}*/

printf("After:");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");

}
