#include<stdio.h>
void main()
{
int a[10],i,ele,sum=0,mul;
ele=sizeof(a)/sizeof(a[0]);
printf("Enter The Numbers:\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=0,mul=1;i<ele;i++)
{
if(a[i]%2==0)
sum+=a[i];
else
mul*=a[i];
}
printf("Sum=%d mul=%d\n",sum,mul);
}


