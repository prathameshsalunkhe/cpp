#include<stdio.h>
void main()
{
	int a[6],ele,i,rev,b,t,k;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
		for(t=a[i],rev=0;t;t/=10)
		{
			b=t%10;
			rev=rev*10+b;
		}
		if(rev==a[i] && a[i]%2!=0)
		{
			for(k=i;k<ele;k++)
				a[k]=a[k+1];
			i--;
			ele--;
		}
	}

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
