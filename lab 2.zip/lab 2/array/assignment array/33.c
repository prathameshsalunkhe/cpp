#include<stdio.h>
void main()
{
	int a[4],b[4],ele,i,fact,n;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0;i<ele;i++)
	{
		for(fact=1,n=1;n<=a[i];n++)
		{
			fact*=n;
		
		}
		b[i]=fact;
	}

	for(i=0;i<ele;i++)
		printf("%d ",b[i]);
}


