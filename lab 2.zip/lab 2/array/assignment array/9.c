#include<stdio.h>
void main()
{
	int a[5]={10,15,64,100,511},i,ele,c=0,d=0,pos;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
	{
		for(pos=31;pos>=0;pos--)
		{
			if(a[i]>>pos&1)
				c++;
			else
				d++;
		}
	}
	printf("Set bits=%d clear bits=%d\n",c,d);
}


