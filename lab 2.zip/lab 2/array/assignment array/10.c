#include<stdio.h>
void main()
{
	int a[5]={10,15,64,100,511},i,ele,c,b[5],pos,j,ele1;
	ele=sizeof(a)/sizeof(a[0]);
	ele1=sizeof(b)/sizeof(a[0]);

	for(i=0;i<ele;i++)
	{
		for(pos=31,c=0;pos>=0;pos--)
		{
			if(a[i]>>pos&1)
			{
				c++;
				//b[i]=c;
			}
		}
				b[i]=c;
	}
	for(i=0;i<ele1;i++)
	printf("%d ",b[i]);
	printf("\n");
}

