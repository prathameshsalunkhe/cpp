#include<stdio.h>
void main()
{
int a[5]={11,22,33,44,55},*p=a,ele,i;
ele=sizeof(a)/sizeof(a[0]);
for(i=0;i<ele;i++)
printf("%d ",*p++);
}

