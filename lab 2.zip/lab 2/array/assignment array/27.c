#include<stdio.h>
void main()
{
	int a[6]={11,12,14,13,15,18},i,ele,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
		if(a[i]%2!=0)
		{
			for(j=i;j<ele;j++)
				a[j]=a[j+1];
			ele--;
			i--;
		}
	}

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
