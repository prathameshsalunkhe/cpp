#include<stdio.h>
void main()
{
	int a[7],ele,i,j,t;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
	t=a[ele-1];

	for(i=ele-1;i>=0;i--)
	{
		a[i]=a[i-1];
	}
	a[0]=t;

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}

