#include<stdio.h>
void main()
{
	int a[7],ele,i,c,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0,c=0;i<ele;i++)
	{
		for(j=2;j<=a[i];j++)
		{
			if(a[i]%j==0)
				break;
		}
		if(a[i]==j)
		{
			c++;
			printf("%d ",a[i]);
		}
	}
	printf("Count of Prime Number:%d\n",c);

}


