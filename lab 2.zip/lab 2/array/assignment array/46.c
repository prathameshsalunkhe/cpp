#include<stdio.h>
void main()
{
	int a[7],ele,i,n,j;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0,n=1;i<ele;n++)
	{
		for(j=2;j<n;j++)
		{
			if(n%j==0)
				break;
		}
		if(n==j)
		{
			a[i]=n;
			i++;
		}
	}

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}

