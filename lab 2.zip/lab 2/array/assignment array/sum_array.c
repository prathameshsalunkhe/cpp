#include<stdio.h>
void main()
{
int a[5]={10,20,30,40,50},sum=0,ele,i;
ele=sizeof(a)/sizeof(a[0]);
for(i=0;i<ele;i++)
sum+=a[i];
printf("Sum=%d\n",sum);
}
