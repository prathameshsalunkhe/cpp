#include<stdio.h>
void main()
{
	int a[5],ele,i,sum,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0;i<ele;i++)
	{
		for(j=1,sum=0;j<a[i];j++)
		{
			if(a[i]%j==0)
				sum+=j;
		}
		if(a[i]==sum)
		{
			printf("Perfect Number=%d pos=%d\n",a[i],i);
	//	return;
	break;
		}
	}
}
