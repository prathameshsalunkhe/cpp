#include<stdio.h>
void main()
{
	int a[7],ele,i,l,t,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	l=ele;

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
		if(a[i]<0)
		{
			t=a[i];
			for(j=i;j<l;j++)
				a[j]=a[j+1];
			i--;
			ele--;
			a[j-1]=t;
		}
	}

	printf("After:");
	for(i=0;i<l;i++)
		printf("%d ",a[i]);
	printf("\n");
}
