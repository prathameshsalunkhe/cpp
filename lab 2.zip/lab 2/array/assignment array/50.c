#include<stdio.h>
void main()
{
	int a[6],ele,i,sum,j,k,fact,n,t;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
		for(t=a[i],sum=0;t;t/=10)
		{
			j=t%10;
			for(n=1,fact=1;n<=j;n++)
				fact*=n;
			sum+=fact;
		}
		if(a[i]==sum)
		{
			for(k=i;k<ele;k++)
			{
				a[k]=a[k+1];
			}
			i--;
			ele--;
		}

	}
	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
