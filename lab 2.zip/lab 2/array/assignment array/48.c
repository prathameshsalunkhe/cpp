#include<stdio.h>
void main()
{
	int a[8],ele,i,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
		for(j=2;j<i;j++)
		{
			if(i%j==0)
				break;
		}
		if(i==j)
			a[i]=0;
	}

	printf("Aftre:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
