#include<stdio.h>
void main()
{
	int a[7],ele,i,num,index;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele-1;i++)
		scanf("%d",&a[i]);
	printf("Enter the number And index:\n");
	scanf("%d%d",&num,&index);

	printf("Before:");
	for(i=0;i<ele-1;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=ele;i>=0;i--)
	{
		a[i]=a[i-1];
		if(i==index)
		{
			a[i]=num;
			break;
		}
	}

	//	a[0]=num;

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
