#include<stdio.h>
void main()
{
	int a[9],i,ele,num,num1,index,index1,b;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele-2;i++)
		scanf("%d",&a[i]);
	printf("Enter The 2 numbers & 2 index:\n");
	scanf("%d%d%d%d",&num,&num1,&index,&index1);

	printf("Before:");
	for(i=0;i<ele-2;i++)
		printf("%d ",a[i]);
	printf("\n");

/*	for(i=ele-1;i>=index1+1;i--)
	{
		a[i]=a[i-2];

		if(i==index)
			a[i]=num;

		else if(i==index1)
			a[i]=num1;
		
		
	}*/
	//a[index]=num;
	//a[index1]=num1;

	for(i=ele;i>=0;i--)
	{
		a[i]=a[i-1];
		if(i==index)
		{
			a[i]=num;
			break;
		}
	}

	for(i=ele;i>=0;i--)
	{
		a[i]=a[i-1];
		if(i==index1)
		{
			a[i]=num1;
			break;
		}
	}
	

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
