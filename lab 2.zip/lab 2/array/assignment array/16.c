#include<stdio.h>
void main()
{
	int a[6],ele,i,*p,*q,t;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	p=a;
	q=a+5;

*p^=*q^=*p^=*q;
	/*t=*p;
	*p=*q;
	*q=t;*/

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

}
