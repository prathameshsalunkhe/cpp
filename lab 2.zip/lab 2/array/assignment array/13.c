#include<stdio.h>
void main()
{
	int a[7],ele,i,L,SL;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	if(a[0]>a[1])
	{
		L=a[0];
		SL=a[1];
	}
	else if(a[1]>a[0])
	{
		L=a[1];
		SL=a[0];
	}

	for(i=2;i<ele;i++)
	{
		if(a[i]>L)
		{
			SL=L;
			L=a[i];
		}
		else if(a[i]>SL && a[i]!=L)
			SL=a[i];
	}
	printf("L=%d SL=%d\n",L,SL);
}


