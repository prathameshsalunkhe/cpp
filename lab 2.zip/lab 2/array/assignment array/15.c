#include<stdio.h>
void main()
{
	int a[6],ele,i,t,j,k;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	printf("Enter The 2 index for swap:\n");
	scanf("%d%d",&j,&k);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	t=a[j];
	a[j]=a[k];
	a[k]=t;

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

}
