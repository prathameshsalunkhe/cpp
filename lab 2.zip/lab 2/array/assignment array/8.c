#include<stdio.h>
void main()
{
int a[5]={12,10,35,63,512},ele,i;
ele=sizeof(a)/sizeof(a[0]);

for(i=0;i<ele;i++)
printf("%d ",a[i]>>1);
printf("\n");
}
