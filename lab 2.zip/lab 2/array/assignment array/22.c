#include<stdio.h>
void main()
{
	int a[3]={1,5,7},b[3]={11,22,33},c[6],ele,i,j,ele1;
	ele=sizeof(a)/sizeof(a[0]);
	ele1=sizeof(c)/sizeof(c[0]);
	printf("%p\n",a);
	printf("%p\n",b);
	for(i=0,j=0;i<ele;i++,j=j+2)
	{
		c[j]=a[i];
		c[j+1]=b[i];
	}
	for(i=0;i<ele1;i++)
		printf("%d ",c[i]);
}

