#include<stdio.h>
void main()
{
	int a[10],i,ele,j,k,c;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0;i<ele;i++)
	{
		for(j=i+1,c=1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
				c++;
				for(k=j;k<ele;k++)
					a[k]=a[k+1];
				j--;
				ele--;
			}
		}
		if(c>=2)
			printf("%d=%d\n",a[i],c);

	}

}
