#include<stdio.h>
void main()
{
	int a[10]={-11,11,12,-12,9,8,-3,10,22},ele,i,p=0,n=0,e=0,o=0;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
	{
		if(a[i]>0 && a[i]%2==0)
		{
			p++;
			e++;
		}
		else if(a[i]>0 && a[i]%2!=0)
		{
			p++;
			o++;
		}

		else if(a[i]<0)
			n++;
	}
	printf("+ve=%d -ve=%d odd=%d even=%d\n",p,n,o,e);
}

