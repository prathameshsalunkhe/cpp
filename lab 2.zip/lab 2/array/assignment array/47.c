#include<stdio.h>
void main()
{
	int a[7],ele,i,sum,j,k;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
		for(j=1,sum=0;j<a[i];j++)
		{
			if(a[i]%j==0)
				sum+=j;
		}
		if(a[i]==sum)
		{
			for(k=i;k<ele;k++)
			{
				a[k]=a[k+1];
			}
				i--;
				ele--;
		}

	}
		printf("After:");
		for(i=0;i<ele;i++)
			printf("%d ",a[i]);
		printf("\n");
}
