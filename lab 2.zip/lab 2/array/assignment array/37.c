#include<stdio.h>
void main()
{
	int a[7],ele,i,c,sum,t,n,b,mul,d,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0,d=0;i<ele;i++)
	{
		for(t=a[i],c=0;t;t/=10,c++);
		for(t=a[i],sum=0;t;t/=10)
		{
			b=t%10;
			for(j=0,mul=1;j<c;j++)
				mul*=b;
			sum+=mul;
		}
		if(sum==a[i])
		{
			d++;
			printf("%d ",a[i]);
		}


	}
		printf("Count of Armstrong Number:%d\n",d);
	}
