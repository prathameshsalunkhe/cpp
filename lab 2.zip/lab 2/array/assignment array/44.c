#include<stdio.h>
void main()
{
	int a[7],ele,i,l,t,j,k=0;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	l=ele;

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=ele-1;i>=k;i--)
	{
		if(a[i]==0)
		{
			t=a[i];
			for(j=i;j>=k;j--)
				a[j]=a[j-1];
			k++;
			i++;
			a[j]=t;
		}
	}

	printf("After:");
	for(i=0;i<l;i++)
		printf("%d ",a[i]);
	printf("\n");
}
