#include<stdio.h>
void main()
{
	int a[7],ele,i,j,t,r;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
		printf("Enter The Number Of Rotation:\n");
		scanf("%d",&r);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
	
        for(j=0;j<r;j++)
	{
	t=a[0];
	for(i=0;i<ele;i++)
		a[i]=a[i+1];
	a[ele-1]=t;
	}

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}

