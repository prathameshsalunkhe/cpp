#include<stdio.h>
void main()
{
	int a[5]={99,88,77,66,55},index,index1,i,ele;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
	printf("Enter The 2 Index:\n");
	scanf("%d%d",&index,&index1);

	for(i=0;i<ele;i++)
	{
		if(i==index)
		{
			for(i;i<ele;i++)
				a[i]=a[i+1];		
		}
	}
	for(i=0;i<ele;i++)
	{
		if(i==index1-1)
		{
			for(i;i<ele;i++)
				a[i]=a[i+1];
		}

	}
	printf("After:");
	for(i=0;i<ele-2;i++)
		printf("%d ",a[i]);
	printf("\n");
}
