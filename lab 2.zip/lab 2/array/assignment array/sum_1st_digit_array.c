#include<stdio.h>
void main()
{
int a[5]={123,23,89,3425,721},ele,i,sum,c,d,t,b;
ele=sizeof(a)/sizeof(a[0]);
for(i=0,sum=0;i<ele;i++)
{
for(t=a[i],c=0;t;t/=10,c++);
for(a[i],d=0;a[i];a[i]/=10)
{
b=a[i]%10;
d++;
if(d==c)
sum+=b;
}
}
printf("Sum=%d\n",sum);
}
