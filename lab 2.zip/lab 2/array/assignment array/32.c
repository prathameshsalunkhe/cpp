#include<stdio.h>
void main()
{
	int a[5],ele,i,b,mul;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	for(i=0;i<ele;i++)
	{
		for(mul=1;a[i];a[i]/=10)
		{
			b=a[i]%10;
			mul*=b;
		}
		a[i]=mul;
	}

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
}


