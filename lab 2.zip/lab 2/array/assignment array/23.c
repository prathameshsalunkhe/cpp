#include<stdio.h>
void main()
{
	int a[2]={1,5},b[4]={11,22,33,44},c[6],ele,ele1,ele2,i,j;
	ele=sizeof(a)/sizeof(a[0]);
	ele1=sizeof(b)/sizeof(b[0]);
	ele2=sizeof(c)/sizeof(c[0]);

	for(i=0,j=0;a[i]||b[i];i++)
	{
		if(i<ele)
			c[j++]=a[i];
		if(i<ele1)
			c[j++]=b[i];
	}


	for(i=0;i<ele2;i++)
		printf("%d ",c[i]);
}
