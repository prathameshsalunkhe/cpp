#include<stdio.h>
void main()
{
	int a[7],ele,i,M,SM;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	if(a[0]<=a[1])
	{
		M=a[0];
		SM=a[1];
	}
	else if(a[1]<=a[0])
	{
		M=a[1];
		SM=a[0];
	}

	for(i=2;i<ele;i++)
	{
		if(a[i]<M)
		{
			SM=M;
			M=a[i];
		}
		else if(a[i]<=SM && a[i]!=M)
			SM=a[i];
	}
	printf("M=%d SM=%d\n",M,SM);
}


