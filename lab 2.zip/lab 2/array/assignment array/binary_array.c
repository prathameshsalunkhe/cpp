#include<stdio.h>
void main()
{
	int a[5]={10,100,1000,100,10},pos,ele,i;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
	{
		printf("Binary of %d is:\n",a[i]);
		for(pos=31;pos>=0;pos--)
		{
			printf("%d",a[i]>>pos&1);
			if(pos%8==0)
				printf(" | ");
		}
		printf("\n");
	}
}
