#include<stdio.h>
void main()
{
	int a[6]={12,234,321,45,654,1234},c,t,rev,ele,i,b,rev1;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
	{
		for(rev=0;a[i];a[i]/=10)
		{
			b=a[i]%10;
			rev=b+rev*10;
		}
		rev=rev/10;
		for(rev1=0;rev;rev/=10)
		{
			c=rev%10;
			rev1=c+rev1*10;
		}
		printf("%d ",rev1);
	}
}


