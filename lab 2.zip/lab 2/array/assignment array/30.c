#include<stdio.h>
void main()
{
	int a[10],i,ele,j,k;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

	for(i=0;i<ele;i++)
	{
	if(a[i]%2==0)
	{
		for(j=i+1;j<ele;j++)
		{
			if(a[i]==a[j])
			{
			for(k=j;k<ele;k++)
				a[k]=a[k+1];
			ele--;
			j--;
			}
		}
	}
	}

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");
}
