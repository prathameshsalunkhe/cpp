#include<stdio.h>
void main()
{
	int a[5],ele,i,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele; ){

		scanf(" %d",&a[i]);
		int k=a[i]&(a[i]-1);
		if(k==0){
			i++;
		}
	}
	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
	printf("\n");

}
