#include<stdio.h>
void main()
{
int a[5],i,ele;
ele=sizeof(a)/sizeof(a[0]);
printf("Enter The Element:\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

for(i=ele-1;i>=0;i--)
printf("%d ",a[i]);
printf("\n");
}
