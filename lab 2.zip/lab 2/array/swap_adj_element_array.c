#include<stdio.h>
void main()
{
int a[5],i,j,ele,t;
ele=sizeof(a)/sizeof(a[0]);
printf("Enter The Element:\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

printf("Before:");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");

for(i=0;i<ele-1;i+=2)
{
t=a[i];
a[i]=a[i+1];
a[i+1]=t;
}

/*for(i=0,j=1;i<ele-1;i+=2,j+=2)
{
t=a[i];
a[i]=a[j];
a[j]=t;
}*/

printf("After:");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");

}
