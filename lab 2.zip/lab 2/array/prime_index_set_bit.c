#include<stdio.h>
void main()
{
	int a[7]={1,2,3,4,5,6,7},ele,i,c,k,pos;
	ele=sizeof(a)/sizeof(a[0]);

	for(i=0;i<ele;i++)
	{
		for(k=2;k<i;k++)
		{
			if(i%k==0)
				break;
		}
		if(i==k)
		{
			for(c=0,pos=31;pos>=0;pos--)
			{
				if(a[i]>>pos&1)
					c++;
			}
			printf("Count of %d index of set bits is:%d\n",i,c);

		}
	}
}
