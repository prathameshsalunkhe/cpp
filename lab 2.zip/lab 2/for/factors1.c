#include<stdio.h>
void main()
{
int num,i,c=0,sum=0;
printf("Enter the num:\n");
scanf("%d",&num);

for(i=1;i<=num;i++)
{
   if(num%i==0)
   {
   sum+=i;
   c++;
   }
}
printf("sum=%d count=%d\n",sum,c);

}
