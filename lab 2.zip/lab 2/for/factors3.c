#include<stdio.h>
void main()
{
int num,a,i,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);
for(  ;num;num=num/100)
{
if(num>0)
a=num%10;
goto L1;
printf("%d ",a);

  
L1:
printf("Factors of %d are: ",a);
for(i=1;i<=a;i++)
if(a%i==0)
printf("%d ",i);
sum+=i;
printf("sum=%d",sum);
printf("\n");

}


}
