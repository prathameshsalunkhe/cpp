#include<stdio.h>
void main()
{
        int num,m,bits,op,r,pos;
	printf("Enter The Number:\n");
	scanf("%d",&num);
	printf("Before:\n");

	for(pos=31;pos>=0;pos--)
		printf("%d",num>>pos&1);
	printf("\n");

//L1:

	printf("Enter bits:\n");
	scanf("%d",&bits);
	if(bits<16)
	{
		printf("Enter The option\n1)Right shift rotation\n2)Left shift rotation\n");
		scanf("%d",&op);
		if(op==1)
		{
			for(r=0;r<bits;r++)
			{
				m=num&1;
				num=num>>1;
				if(m)
					num=num | 1<<31;
			}
		}
		else if(op==2)
		{
			for(r=0;r<bits;r++)
			{
				m=num&1<<31;
				num=num<<1;
				if(m)
					num=num | 1;
			}
		//goto L1;
		}
		printf("Afer:\n");

		for(pos=31;pos>=0;pos--)
			printf("%d",num>>pos&1);
		printf("\n");
	}


}


