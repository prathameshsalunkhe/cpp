#include<stdio.h>
void main()
/*{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=2;j++)
			printf("%d ",j);
	}
}*/

/*{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=i;j<=2;j++)
			printf("%d ",i);
			printf("\n");
	}
}*/

/*{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=2-i;j++)
			printf("%d ",i);
			printf("\n");
	}
}*/

/*{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=i;j++)
			printf("%d ",j);
			printf("\n");
	}
}*/
/*{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=i;j++)
			printf("%c ",'a'+j);
			printf("\n");
	}
}*/
/*{
	int i,j;
	for(i=0;i<=2;i++)
	{
		for(j=0;j<=i;j++)
			printf("%c ",'a'+i);
			printf("\n");
	}
}*/
{
	int i,j;
	char ch;
	for(i=0,ch='a';i<=2;i++,ch++)
	{
		for(j=0;j<=i;j++)
			printf("%c ",ch);
			printf("\n");
	}
}
