#include<stdio.h>
void main()
{
int num,pos,m,r,bits;
printf("Enter The Number & bits:\n");
scanf("%d%d",&num,&bits);
printf("Before: ");

for(pos=31;pos>=0;pos--)
{
printf("%d",num>>pos&1);
}
printf("\n");

for(r=0;r<bits;r++)
{
m=num&1<<31;
num=num<<1;
if(m)
num= num | 1;
}

printf("After: ");

for(pos=31;pos>=0;pos--)
{
printf("%d",num>>pos&1);
}
printf("\n");





}
