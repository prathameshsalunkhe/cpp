/* a B c D e
   F g H i
   J k L
   m N 
   o          */

////////////////////////////////

#include<stdio.h>
void main()
{
	int i,j;
	char ch;
	for(i=0,ch='a';i<5;i++)
	{
		for(j=0;j<5-i;j++,ch=ch^32)
			printf("%c",ch++);
		printf("\n");
	}
}


