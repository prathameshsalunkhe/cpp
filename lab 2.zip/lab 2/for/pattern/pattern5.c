/* * * * * *
   * g H i
   * k L
   * N
   *          */

//////////////////////////////

#include<stdio.h>
void main()
{
	int i,j;
	char ch;
	for(i=0,ch='a';i<5;i++)
	{
		for(j=0;j<5-i;j++,ch++,ch=ch^32)
		{
			if(i==0 || j==0)
				printf("*");
			else
				printf("%c",ch);
		}
		printf("\n");
	}
}
