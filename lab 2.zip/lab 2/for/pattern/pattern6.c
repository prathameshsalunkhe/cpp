/* * * * * *
   *     *
   *   *
   * *
   *          */

//////////////////////////////

#include<stdio.h>
void main()
{
	int i,j;
	
	for(i=0;i<5;i++)
	{
		for(j=0;j<5-i;j++)
		{
			if(i==0 || j==0 || j==4-i)
				printf("* ");
			/*else if(i==1 && j==3)
				printf("  *");
				else if(i==2 && j==2)
				printf(" *");
				else if(i==3 && j==1)
				printf("*");*/
				else 
				printf("  ");

		}
		printf("\n");
	}
}
