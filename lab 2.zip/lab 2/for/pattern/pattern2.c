/* a
   1 2
   a b c
   1 2 3 4
   a b c d e */


////////////////////////////

#include<stdio.h>
void main()
{
	int i,j;
	for(i=0;i<5;i++)
	{
		for(j=0;j<=i;j++)
		{
			if(i%2==0)
				printf("%c",'a'+j);
			else
				printf("%d",1+j);
		}
		printf("\n");
	}
}
