#include<stdio.h>
void main()
{
int num,r,sum=0,mul=1;
printf("Enter the num:\n");
scanf("%d",&num);
for(  ;num;num=num/10)
{
r=num%10;
if(r%2==0)
sum+=r;
else
mul*=r;

}	
printf("sum=%d\nmul=%d\n",sum,mul);
}

