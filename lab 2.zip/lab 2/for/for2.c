#include<stdio.h>
void main()
{
	int num,a,c=0;
	printf("Enter the number:\n");
	scanf("%d",&num);

	for(  ;num;num=num/10)
	{
		a=num%10;
		if(a%3==0)
		c++;
			

	}
		printf("c=%d\n",c);

}
