#include<iostream>
using namespace std;
class A
{
	int x,y;
	public:
	A():x(10),y(20){}
	void get_data()
	{
		cout<<x<<" "<<y<<endl;
	}

	void operator ()(int a,int b)
	{
		x=a,y=b;
	}
};

int main()
{
	A obj1;
	obj1.get_data();
	obj1(100,200);
	obj1.get_data();
}
