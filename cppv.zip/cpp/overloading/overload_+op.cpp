#include<iostream>
using namespace std;
class A
{
	int x,y;
	public:
	A()
	{
		x=0;
		y=0;
	}
	A(int a,int b)
	{
		x=a;
		y=b;
	}
	void get_data()
	{
		cout<<x<<" "<<y<<endl;
	}
	friend A operator +(A t1,A t2);
	//A operator +(A t);
/*	{
		A r;
		r.x=x+t.x;
		r.y=y+t.y;
		return r;
	}*/
};

A operator +(A t1,A t2)
{
	A r;
	r.x=t1.x+t2.x;
	r.y=t1.y+t2.y;
	return r;
}

int main()
{
	A obj1(10,20),obj2(30,40),obj3,obj4;
	obj3=obj1+obj2;
	obj4=obj1+obj2+obj3;
	obj3.get_data();
	obj4.get_data();
}
