#include<iostream>
using namespace std;
class A
{
	int x,y;
	public:
	A()
	{
		x=0;
		y=0;
	}
	A(int a,int b)
	{
		x=a;
		y=b;
	}
	void get_data()
	{
		cout<<x<<" "<<y<<endl;
	}
	A operator =(A t)
	{
		x=t.x;
		y=t.y;
		return *this;
	}
};

int main()
{
	A obj1(100,200),obj2,obj3;
	obj3=obj2=obj1;
	obj2.get_data();
	obj3.get_data();
}
