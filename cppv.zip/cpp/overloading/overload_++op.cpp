#include<iostream>
using namespace std;
class A
{
	int x,y;
	public:
		A():x(10),y(20){}
		A(int a,int b):x(a),y(b){}
		void get_data()
		{
			cout<<x<<" "<<y<<endl;
		}
		A operator --(int)       //post increment
		{
			return A(x--,y--);
		}

		A operator --()         // pre increment
		{
			return A(--x,--y);
		}
};

int main()
{
	A obj1,obj2(100,200),obj3;
	obj3=obj1--;
	obj3.get_data();
	obj3=--obj2;
	obj3.get_data();
}
