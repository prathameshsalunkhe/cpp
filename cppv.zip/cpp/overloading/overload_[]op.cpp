#include<iostream>
using namespace std;
class A
{
	int a[5];
	public:
	int & operator [](int i)
	{
		return a[i];
	}
};

int main()
{
	A obj1;
	int i;
	for(i=0;i<5;i++)
		cin>>obj1[i];
	
	for(i=0;i<5;i++)
		cout<<obj1[i]<<" ";
		cout<<endl;
}
