#include<iostream>
using namespace std;
class A
{
	string name;
	int age;
	public:
		A()
		{
			cout<<"Enter The Name And Age: "<<endl;
			cin>>name>>age;
		}
		void get_data()
		{
			cout<<name<<" "<<age<<endl;
		}
};

class Smart
{
	A *p;
	public:
		Smart()
		{
			p=new A;
		}
		A *operator ->()
		{
			return p;
		}
		A operator *()
		{
			return *p;
		}
};

int main()
{
	Smart obj1,obj2;
	obj1->get_data();
	(*obj2).get_data();
}

