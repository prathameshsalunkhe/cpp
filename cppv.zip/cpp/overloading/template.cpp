#include<iostream>
using namespace std;
template<class type>
double area(type l,type b)
{
	cout<<"Area Of Rectangle"<<endl;
	return l*b;
}

template<class type>
double area(type r)
{
	cout<<"Area Of Circle"<<endl;
	return 3.14*r*r;
}

int main()
{
	cout<<area(2,4)<<endl;
	cout<<area(2.3,4.5)<<endl;
	cout<<area(3)<<endl;
	cout<<area(3.4)<<endl;
}
