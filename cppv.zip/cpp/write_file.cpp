#include<iostream>
#include<fstream>
using namespace std;
int main()
{
	ofstream fout("data2");
	fout<<"Vector India"<<endl;
	fout<<"banglore"<<endl;
	fout.close();
}
