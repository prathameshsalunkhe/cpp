#include<iostream>
#include<cstring>
using namespace std;
class matrix
{
	int **p1,**p2,**p3;
	int r,c;
	public:
		matrix()
		{
			
