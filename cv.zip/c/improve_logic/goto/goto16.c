#include<stdio.h>
void main()
{
	int num,pos=0,c=0,m;
	printf("Enter The Number:\n");
	scanf("%d",&num);

L1:
	if(pos<=31)
	{
		m=num>>pos&1;
		pos++;
		if(m)
			c++;
		goto L1;
	}
	printf("set bit count=%d\n",c);
}

