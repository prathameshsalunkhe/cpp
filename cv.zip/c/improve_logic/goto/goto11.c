#include<stdio.h>
void main()
{
	int num,temp,a,rev=0;
	printf("Enter The Number:\n");
	scanf("%d",&num);
	temp=num;

L1:
	if(temp>0)
	{
		a=temp%10;
		rev=a+(rev*10);
		temp=temp/10;
		goto L1;
	}
	if(num==rev)
		printf("Palindrom Number\n");
	else
		printf("Not Palidrom Number\n");
}
