#include<stdio.h>
void main()
{
int num,i=1,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);

L1:
if(num>0)
{
   if(num%i==0)
   {
   c++;
   i++;
   }
   else
   i++;
   if(i<=num)
   goto L1;
}
printf("count of factors=%d\n",c);
}


