#include<stdio.h>
void main()
{
	int num,i=1,sum=0;
	printf("Enter the number:\n");
	scanf("%d",&num);

L1:
	if(num>0)
	{
		if(num%i==0)
		sum+=i;
		i++;
                if(i<num)
		goto L1;
		
	}
	if(num==sum)
		printf("Perfect Number\n");
	else
		printf("Not Perfect Number\n");
}


