#include<stdio.h>
void main()
{
int num,i=1;
printf("Enter The Number:\n");
scanf("%d",&num);
printf("Factors of %d are: ",num);
L1:
if(num>0)
{
   if(num%i==0)
   {
      if(i%2==0)
      printf("%d ",i);
      i++;
   }
   else
   i++;
   if(i<=num)
   goto L1;
 }
}		
