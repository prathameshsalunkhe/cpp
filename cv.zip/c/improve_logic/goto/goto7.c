#include<stdio.h>
void main()
{
int num,i=1,c=0;
printf("Enter the number:\n");
scanf("%d",&num);

L1:
if(num>0)
{
if(num%i==0)
c++;
i++;
if(i<=num)
goto L1;
}
if(c==2)
printf("Prime Number\n");
else
printf("Not Prime Number\n");
}


