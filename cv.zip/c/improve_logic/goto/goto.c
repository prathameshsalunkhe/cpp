#include<stdio.h>
void main()
{
int num,factorial=1,i=1;
printf("Enter the number:\n");
scanf("%d",&num);
L1:
{
factorial*=i;
i++;
if(i<=num)
goto L1;
}
printf("Factorial of %d is %d\n",num,factorial);
}


