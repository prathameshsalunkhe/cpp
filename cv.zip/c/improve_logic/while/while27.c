#include<stdio.h>
void main()
{
int num,a,b,rev=0,temp,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);


temp=num;
b=num%10;
sum=sum+b;

while(temp)
{
a=temp%10;
rev=a+rev*10;
temp/=10;
}
b=rev%10;
sum+=b;
printf("Sum=%d\n",sum);

}
