#include<stdio.h>
void main()
{
int num,pos=31,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);

while(pos>=0)
{
if(num>>pos&1)
c++;
pos--;
}
printf("Count Of Set bits:%d\n",c);
}
