#include<stdio.h>
void main()
{
int num,num1,c=0;
printf("Enter The Num & Num1:\n");
scanf("%d%d",&num,&num1);

while(num<=num1)
{
if(num%2!=0)
{
c++;
if(c%2!=0)
printf("%d ",num);
}
num++;
}
}
