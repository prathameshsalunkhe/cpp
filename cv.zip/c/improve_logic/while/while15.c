#include<stdio.h>
void main()
{
int num,a,rev=0,temp,b;
printf("Enter The Number:\n");
scanf("%d",&num);

temp=num;
while(temp)
{
a=temp%10;
rev=a+rev*10;
temp/=10;
}
b=rev%10;
printf("%d",b);
}
