#include<stdio.h>
void main()
{
int num,i=1,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);

while(i<=num)
{
if(num%i==0)
{
if(i%2!=0)
printf("%d ",i);
}
i++;
}
}
