#include<stdio.h>
void main()
{
int pos=31;
char ch;
printf("Enter The Character:\n");
scanf("%c",&ch);

while(pos>=0)
{
printf("%d",ch>>pos&1);
if(pos%8==0)
printf(" | ");
pos--;
}
}
