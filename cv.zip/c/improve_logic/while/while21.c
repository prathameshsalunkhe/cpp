#include<stdio.h>
void main()
{
int num,a,rev=0,temp,b,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);

temp=num;
while(temp)
{
a=temp%10;
rev=a+rev*10;
temp/=10;
}
rev%=1000;
while(rev)
{
b=rev%10;
sum+=b;
rev/=10;
}
printf("sum=%d",sum);
}
