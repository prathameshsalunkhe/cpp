#include<stdio.h>
void main()
{
int num,a,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);

while(num)
{
a=num%10;
if(a%2!=0 && c<1)
{
printf("%d ",a);
c++;
}
num/=10;
}
}
