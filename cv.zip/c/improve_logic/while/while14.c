#include<stdio.h>
void main()
{
int num,a;
printf("Enter The Number:\n");
scanf("%d",&num);

num%=1000;
while(num)
{
a=num%10;
printf("%d ",a);
num/=10;
}
}
