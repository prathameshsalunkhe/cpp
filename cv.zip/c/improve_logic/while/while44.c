#include<stdio.h>
void main()
{
int num=1,r;

while(num<=6)
{
r=(num*num*num)+1;
printf("%d ",r);
num++;
}
}
