#include<stdio.h>
void main()
{
int num,pos=31,i,j,m,n;
printf("Enter The Number:\n");
scanf("%d",&num);

printf("Before Swap:");

while(pos>=0)
{
printf("%d",num>>pos&1);
if(pos%4==0)
printf(" | ");
pos--;
}

for(i=0,j=8;i<=3;i++,j++)
{
m=num>>i&1;
n=num>>j&1;
if(m!=n)
{
num=num^1<<i;
num=num^1<<j;
}
}
printf("\n");
printf("After Swap:");
pos=31;

while(pos>=0)
{
printf("%d",num>>pos&1);
if(pos%4==0)
printf(" | ");
pos--;
}
}
