#include<stdio.h>
void main()
{
int num=1,k=0;

while(k<=6)
{
num+=k;
printf("%d ",num);
k++;
}
}
