#include<stdio.h>
void main()
{
int num,temp,a,b,c=0,d=0,sum=0;
printf("Enter The Number:\n");
scanf("%d",&num);
temp=num;
l1:
if(temp>0)
    {
        a=temp%10;
	c++;
	temp=temp/10;
	goto l1;
    }
    
    l2:
    if(num>0)
       {
           b=num%10;
	   d++;
	   if(d==2 || d==c)
	   {
	   sum+=b;
	   num=num/10;
	   }
	   else 
	   num=num/10;
	   goto l2;
        }
	printf("sum=%d\n",sum);

}
