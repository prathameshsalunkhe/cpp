/* 1  
   2 1 
   3 2 1       */

///////////////////////////

#include<stdio.h>
void main()
{
int i,j,n;
for(i=0;i<3;i++)
{
for(j=0,n=1+i;j<=i;j++)
printf("%d ",n--);
printf("\n");
}
}
