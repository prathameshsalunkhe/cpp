/* 1 2 3
   1 2 
   1       */

///////////////////////////

#include<stdio.h>
void main()
{
int i,j,n;
for(i=0;i<3;i++)
{
for(j=0,n=3-i;j<3-i;j++)
printf("%d ",n--);
printf("\n");
}
}
