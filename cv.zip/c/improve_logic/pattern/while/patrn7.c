#include<stdio.h>
void main()
{
int i=0,j=0,r,n;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

while(i<r)
{
for(j=0,n=r-i;j<r-i;j++)
printf("%d ",n--);
printf("\n");
i++;
}
}
