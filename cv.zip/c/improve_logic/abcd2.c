#include<stdio.h>
void main()
{
int num,temp,a,b,r;
printf("Enter the num:\n");
scanf("%d",&num);
temp=num;
printf("Before=%d\n",num);

a=num>>3;
a=a<<2;

b=temp<<6;
b=b>>6;

r=a|b;

printf("After=%d\n",r);



}

