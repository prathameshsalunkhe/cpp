#include<stdio.h>
void main()
{
	int num,i;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(i=1;i<=num;i++)
	{
		if(num%i==0)
		{
		if(i%2==0)
			printf("%d ",i);
		}
	}
	
}
