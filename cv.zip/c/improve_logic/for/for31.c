#include<stdio.h>
void main()
{
	int num,pow,c,mul;
	printf("Enter The Number and Power:\n");
	scanf("%d%d",&num,&pow);

	for(c=0,mul=1;c<pow;c++)
		mul*=num;
	printf("power=%d\n",mul);
}
