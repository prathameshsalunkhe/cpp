#include<stdio.h>
void main()
{
int pos,a;
char ch;
printf("Enter Char:\n");
scanf("%c",&ch);

for(pos=31;pos>=0;pos--)
{
a=ch>>pos&1;
printf("%d",a);
}
}
