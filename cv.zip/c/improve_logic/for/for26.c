#include<stdio.h>
void main()
{
	int num,a,rev,c,b;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(rev=0;num;num/=10)
	{
		a=num%10;
		rev=a+(rev*10);			
	}
	for(c=0;c<1;rev/=10)
	{
		b=rev%10;
		if(b%2!=0)
		{
			printf("Odd Digit=%d\n",b);
			c++;
		}
	}
}	
