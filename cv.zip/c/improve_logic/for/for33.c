#include<stdio.h>
void main()
{
	int num,i,c=0;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(i=1,c=0;i<=num;i++)
	{
		if(num%i==0)
		{
			printf("%d ",i);
			c++;
		}
	}
	printf("Count Of Factors:%d\n",c);
}
