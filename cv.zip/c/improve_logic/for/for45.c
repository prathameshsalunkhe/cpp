#include<stdio.h>
void main()
{
int num,pos,c;
printf("Enter The Number:\n");
scanf("%d",&num);

for(pos=31,c=0;pos>=0;pos--)
{
if(num>>pos&1)
c++;
}
printf("Count of Set Bits:%d\n",c);
}

