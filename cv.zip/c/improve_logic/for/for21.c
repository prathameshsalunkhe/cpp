#include<stdio.h>
void main()
{
	int num,a,rev,sum,b,c;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(rev=0;num;num/=10)
	{
		a=num%10;
		rev=a+(rev*10);
	}
	for(sum=0,c=0;c<3;rev/=10)
	{
		b=rev%10;
		sum+=b;
		c++;
	}
	printf("sum:%d\n",sum);
}
