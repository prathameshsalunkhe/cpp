#include<stdio.h>
void main()
{
	int num,sum,c,a;
	printf("Enter The Number:\n");
	scanf("%d",&num);

		for(sum=0,c=0;c<3;num/=10)
		{
			a=num%10;
			sum+=a;
			c++;
		}
	printf("sum=%d",sum);
}
