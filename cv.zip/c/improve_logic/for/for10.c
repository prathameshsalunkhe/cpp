#include<stdio.h>
void main()
{
	int num,c,a;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(c=0;num;num/=10)
	{
		a=num%10;
		if(a%2==0)
		if(a>1 && a<7)
			c++;
	}
	printf("Count of digit:%d",c);
}
