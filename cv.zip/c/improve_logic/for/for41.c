#include<stdio.h>
void main()
{
	int i,j,c;
	printf("Enter starting and ending number:\n");
	scanf("%d%d",&i,&j);

	for(c=0;i<=j;i++)
	{
		if(i%2!=0)
		{
			c++;
			if(c%2!=0)
				printf("%d ",i);
		}
	}
}
