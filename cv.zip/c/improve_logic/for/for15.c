#include<stdio.h>
void main()
{
int num,a;
printf("Enter The Number:\n");
scanf("%d",&num);

for(num;num>10;num/=10);
printf("First Digit:%d",num);
}
