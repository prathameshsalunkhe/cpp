#include<stdio.h>
void main()
{
	int i,j,m,n,num,pos;
	printf("Enter The Number:\n");
	scanf("%d",&num);
        printf("Before:\n");
	for(pos=31;pos>=0;pos--)
	{
		printf("%d ",num>>pos&1);
		if(pos%4==0)
			printf(" | ");
	}

	for(i=0,j=8;i<=3;i++,j++)
	{
		m=num>>i&1;
		n=num>>j&1;
		if(m!=n)
		{
			num=num^1<<i;
			num=num^1<<j;
		}
	}
        printf("After:\n");
	for(pos=31;pos>=0;pos--)
	{
		printf("%d ",num>>pos&1);
		if(pos%4==0)
			printf(" | ");
	}

}

