#include<stdio.h>
void main()
{
	int num,a,c;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(c=0;c<3;num/=10,c++)
	{
		a=num%10;
		printf("%d ",a);
	}
}
