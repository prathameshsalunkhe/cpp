#include<stdio.h>
void main()
{
	int num,a,sum;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(sum=0;num>0;num/=10)
	{
		a=num%10;
		sum+=a;
	}
	printf("sum=%d",sum);
}
