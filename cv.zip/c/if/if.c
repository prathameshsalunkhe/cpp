#include<stdio.h>
void main()
{
int num;
printf("Enter The Number:\n");
scanf("%d",&num);

//if(num%2==0)
if((num&1)==0)
printf("number is even...\n");
else
printf("number is odd...\n");


}
