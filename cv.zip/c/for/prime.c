#include<stdio.h>
void main()
/*{
int num,i,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);

for(i=1;i<=num;i++)
    if(num%i==0)
    c++;
    if(c==2)
        printf("Prime Number\n");
    else
        printf("Not Prime Number\n");

}*/




/*{
int num,i,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);

for(i=2;i<num;i++)
    if(num%i==0)
    c++;
    if(c==0)
        printf("Prime Number\n");
    else
        printf("Not Prime Number\n");

}*/


{
int num,i;
printf("Enter The Number:\n");
scanf("%d",&num);

for(i=2;i<num;i++)
{
    if(num%i==0)
    break;
}
    if(num==i)
        printf("Prime Number\n");
    else
        printf("Not Prime Number\n");

}


