#include<stdio.h>
void main()
{
int num,a,sum=0;
printf("Enter the number:\n");
scanf("%d",&num);

for(  ;num;num=num/10)
{
a=num%10;
if(a%2==0)
sum+=a;
}
printf("sum=%d",sum);
}

