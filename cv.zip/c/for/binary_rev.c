#include<stdio.h>
void main()
{
	int num,pos;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	for(pos=0;pos<=31;pos++)
	{
		printf("%d",num>>pos&1);
		if(pos%8==0)
			printf(" ");
	}
	printf("\n");
}
