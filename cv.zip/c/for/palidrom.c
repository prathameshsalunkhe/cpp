#include<stdio.h>
void main()
{
int num,temp,rev,a;
printf("Enter the number:\n");
scanf("%d",&num);

for(rev=0,temp=num;temp;temp=temp/10)
{
  a=temp%10;
  rev=a+(rev*10);
 }
 if(num==rev)
 printf("Palidrom number\n");
 else
 printf("Not Palidrom number\n");

}

