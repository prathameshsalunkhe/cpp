#include<stdio.h>
void main()
{
int num,i,r,pos=1,c=0;
printf("Enter The Number:\n");
scanf("%d",&num);
printf("Factors of %d are: ",num);
for(i=1;i<=num;i++)
if(num%i==0)
printf("%d ",i);
printf("\n");

printf("Alternate Factors of %d are: ",num);
for(r=1;r<=num;r++)
if(num%r==0)
{
pos++;
c++;
if(pos%2!=0&&c%2==0)
printf("%d=%d  ",c,r);
}

}
