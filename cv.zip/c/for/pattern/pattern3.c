/* a
   1 2 3
   a b c d e
   1 2 3 4 5 6 7
   a b c d e f g h i */

//////////////////////////////////

#include<stdio.h>
void main()
{
	int i,j;
	for(i=0;i<5;i++)
	{
		for(j=0;j<=i*2;j++)
		{
			if(i%2==0)
				printf("%c",'a'+j);
			else
				printf("%d",1+j);
		}
		printf("\n");
	}
}
