#include<stdio.h>
void main()
{
int i=0,j=12,k;

//k=i&&j;
k=i||(j=25);

//k=i&&(j=25);
printf("i=%d j=%d k=%d\n",i,j,k);
}
