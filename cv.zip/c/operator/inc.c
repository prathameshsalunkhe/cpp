#include<stdio.h>
void main()
{
int i=10,j;
printf("%d %d %d %d\n",i,i,i,i);
printf("%d %d %d %d\n",i++,i++,i++,i++);
printf("%d %d %d %d\n",++i,++i,++i,++i);
printf("%d %d %d %d %d %d\n",i++,++i,i,i++,++i,i++);
}

