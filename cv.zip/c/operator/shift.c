#include<stdio.h>
void main()
{
int i=-25,k;
k=i>>4;
printf("%d\n",k);
}
