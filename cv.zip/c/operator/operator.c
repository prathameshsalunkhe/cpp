#include<stdio.h>
void main()
{
int pawan=0x1FF;
pawan = 0x1AA+0777;
printf("%d\n",pawan);
printf("%x\n",pawan);
printf("%o\n",pawan);

}
