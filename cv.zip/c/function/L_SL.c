#include<stdio.h>
void L_SL(int *,int,int *,int *);
void main()
{
	int a[5],ele,i,L,SL;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);
	L_SL(a,ele,&L,&SL);
	printf("L=%d SL=%d\n",L,SL);
}

void L_SL(int *a,int ele,int *p,int *q)
{
	int i;
	if(a[0]>a[1])
	{
		*p=a[0];
		*q=a[1];
	}
	else if(a[1]>a[0])
	{
		*p=a[1];
		*q=a[0];
	}

	for(i=2;i<ele;i++)
	{
		if(a[i]>*p)
		{
			*q=*p;
			*p=a[i];
		}
		else if(a[i]>*q && a[i]!=*p)
			*q=a[i];
	}
}

