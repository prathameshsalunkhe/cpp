#include<stdio.h>
//#include<string.h>
void main()
{
	char m[100],s[20];
	printf("Enter The main&sub string:\n");
	scanf("%s%s",m,s);
	int i,j;

	for(i=0;m[i];i++)
	{
		if(m[i]==s[0])
		{
			for(j=1;s[j];j++)
			{
				if(m[i+j]!=s[j])
					break;
			}
			if(s[j]=='\0')
			{
				printf("Present\n");
				return;
			}
		}
	}
	printf("Not Present\n");
}
