#include<stdio.h>
void print_string(const char *);
void my_strupr(char *);

void main()
{
	char s[20];
	printf("Enter The String:\n");
	scanf("%s",s);
	printf("Before:");
	print_string(s);
	my_strupr(s);
	printf("After:");
	print_string(s);
}

void print_string(const char *s)
{
	while(*s)
		printf(" %c",*s++);
	printf("\n");
}

void my_strupr(char *s)
{
	while(*s)
	{
		if(*s>='a' && *s<='z')
			*s=*s-32;
		s++;
	}
}
