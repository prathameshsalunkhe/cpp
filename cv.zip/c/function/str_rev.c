#include<stdio.h>
void my_strrev(char *);

void main()
{
	char s[20];
	printf("Enter The String:");
	scanf("%s",s);

	printf("%s\n",s);
	my_strrev(s);
	printf("%s",s);
}

void my_strrev(char *s)
{
	char *m,t;
	m=s;
	while(*m)
		m++;
	m--;

	while(s<m)
	{
		t=*s;
		*s=*m;
		*m=t;
		s++;
		m--;
	}
}
