#include<stdio.h>
int count_set_bit(int);
void main()
{
int num,c;
printf("Enter The Number:\n");
scanf("%d",&num);
c=count_set_bit(num);
printf("c=%d\n",c);
}

int count_set_bit(int num)
{
int pos,c;
for(pos=0,c=0;pos<=31;pos++)
if(num>>pos&1)
c++;
return c;
}

