#include<stdio.h>
void print_str(const char *);
void my_strcpy(const char *,char *);

void main()
{
	char s[20],d[20];
	printf("Enter The String:");
	scanf("%s",s);

	print_str(d);
	my_strcpy(s,d);
	print_str(d);
}

void print_str(const char *d)
{
	while(*d)
		printf(" %c",*d++);
	printf("\n");
}

void my_strcpy(const char *s,char *d)
{
	while(*s)
		*d++=*s++;
	*d=*s;
}
