#include<stdio.h>
int count_del_fun(int *,int);
void main()
{
	int a[6],ele,i,c;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Elment:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	c=count_del_fun(a,ele);

	printf("Count Of -ve Number:%d\n",c);

	for(i=0;i<ele-c;i++)
		printf("%d ",a[i]);

}

int count_del_fun(int *a,int ele)
{
	int i,c,j;
	for(i=0,c=0;i<ele;i++)
	{
		if(a[i]>>31&1)
		{
			c++;
			for(j=i;j<ele;j++)
				a[j]=a[j+1];
			ele--;
			i--;
		}
	}
	return c;
}


