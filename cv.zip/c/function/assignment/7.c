#include<stdio.h>
void in_fun(int *,int,int,int);
void main()
{
	int a[6],ele,n,p,i;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele-1;i++)
		scanf("%d",&a[i]);

	printf("Enter The Number:\n");
	scanf("%d",&n);
	printf("Enter The Index:\n");
	scanf("%d",&p);

	in_fun(a,ele,n,p);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
}

void in_fun(int *a,int ele,int n,int p)
{
	int i;
	for(i=ele-1;i>=0;i--)
	{
		a[i]=a[i-1];
		if(i==p)
		{
			a[i]=n;
			break;
		}
	}
}


