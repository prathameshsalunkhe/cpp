#include<stdio.h>
int del_count_fun(char *);
void main()
{
	char s[20];
	int c;
	printf("Enter The String:\n");
	scanf("%s",s);

	c=del_count_fun(s);
	printf("Digit Count:%d\n",c);
	printf("%s",s);
}

int del_count_fun(char *s)
{
	int i,c,k;
	for(i=0,c=0;s[i];i++)
	{
			if(s[i]>='0'&&s[i]<='9')
			{
				c++;
				for(k=i;s[k];k++)
					s[k]=s[k+1];
				i--;
			}
	}
	return c;
}
