#include<stdio.h>
void rotate_fun(int *,int,int);
void main()
{
	int a[6],ele,i,n;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	printf("Enter The Number Of Rotation:\n");
	scanf("%d",&n);

	rotate_fun(a,ele,n);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);

}

void rotate_fun(int *a,int ele,int n)
{
	int i,t,j;
	for(i=0;i<n;i++)
	{
		t=a[ele-1];
		for(j=ele-1;j>=0;j--)
			a[j]=a[j-1];
		a[0]=t;
	}
}



