#include<stdio.h>
void in_fun(int *,int *,int *,int,int,int);
void main()
{
	int a[3],b[3],c[6],ele1,ele2,ele3,i;
	ele1=sizeof(a)/sizeof(a[0]);
	ele2=sizeof(b)/sizeof(b[0]);
	ele3=sizeof(c)/sizeof(c[0]);
	printf("Enter The 1st Array Elements:\n");
	for(i=0;i<ele1;i++)
		scanf("%d",&a[i]);

	printf("Enter The 2nd Array Elements:\n");
	for(i=0;i<ele2;i++)
		scanf("%d",&b[i]);

	in_fun(a,b,c,ele1,ele2,ele3);

	for(i=0;i<ele3;i++)
		printf("%d ",c[i]);
}

void in_fun(int *a,int *b,int *c,int ele1,int ele2,int ele3)
{
	int i,j;
	for(i=0,j=0;j<ele3;i++)
	{
		if(i<ele1)
			c[j++]=a[i];
		if(i<ele2)
			c[j++]=b[i];
	}
}

