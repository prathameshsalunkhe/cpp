#include<stdio.h>
const char *my_strchr(const char *,char);
void main()
{
	char s[20],ch;
	printf("Enter The String:\n");
	scanf("%s",s);
	printf("Enter The Char:\n");
	scanf(" %c",&ch);

	const char *p;
	p=my_strchr(s,ch);
	if(p==0)
		printf("Char Is Not Present\n");
	else
		printf("Char Is Present @ %p location\n",p);
}

const char *my_strchr(const char *s,char ch)
{
	while(*s)
	{
		if(*s==ch)
			return s;
		s++;
	}
	return 0;
}
