#include<stdio.h>
void main()
{
	int num,temp,a,rev;
	for(num=30;num<=130;num++)
	{
		for(temp=num,rev=0;temp;temp/=10)
		{
			a=temp%10;
			rev=a+(rev*10);
		}
		if(rev==num)
			printf("%d ",num);
	}
}
