#include<stdio.h>
void main()
{
	int num,temp,a,c,rev;
	for(num=30,c=0;c<5;num++)
	{
		for(temp=num,rev=0;temp;temp/=10)
		{
			a=temp%10;
			rev=a+(rev*10);
		}
		if(rev==num)
		{
			c++;
			printf("%d ",num);
		}
	}
}
