#include<stdio.h>
void main()
{
int num=011223344,r1,r2,r3,r4;

printf("Before:%o\n",num);

r1=num& 000000044;
r1=r1<<6;
r2=num& 000003300;
r2=r2>>6;
r3=num& 000220000;
r3=r3<<6;
r4=num& 011000000;
r4=r4>> 6;
num=r1|r2|r3|r4;

printf("After:%o\n",num);
}
