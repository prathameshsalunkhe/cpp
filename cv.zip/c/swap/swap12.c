#include<stdio.h>
void main()
{
int num,a,b;

printf("Enter The Num=\n");
scanf("%d",&num);
printf("Before deleting last second digit num=%d\n",num);

a=num%10;
b=num/100;
num=b*10+a;

/*a=num%10;
b=num/10;
c=b%10;
d=b/10;
num=a+c+d;*/

/*a=num%10;
b=num/10;
num=a*10+b;*/

/*a=num%10;
b=num/10;
c=a+b;*/

printf("After deleting last second digit num=%d\n",num);
}
