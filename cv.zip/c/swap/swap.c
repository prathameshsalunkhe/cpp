#include<stdio.h>
void main()
{
int num,r,r1;
printf("Enter The Number....\n");
scanf("%d",&num);
printf("Before swap num=%d\n",num);

r=num%100;
r1=num/100;
num=r*100+r1;


/*t1=n1;
n1=n2;
n2=t1;*/

printf("After swap num=%d",num);
}
