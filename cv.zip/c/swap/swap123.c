#include<stdio.h>
void main()
{
int num,a,b;
printf("Enter The num");
scanf("%d%d",&a,&b);
//int num,a=1,b=8;
//int num,a=9,b=2;

num=3*a*b*b+a*a*a+3*b*a*a+b*b*b;
//num=a*a+2*a*b+b*b;

printf("num=%d\n",num);
}
