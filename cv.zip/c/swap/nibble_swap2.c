#include<stdio.h>
void main()
{
//int num=012345673,r1,r2,r3,r4,r5,r6,r7,r8;
int num=012345673,r1,r2;

printf("Before:%o\n",num);

/*r1=num&000000003;
r1=r1<<3;
r2=num&000000070;
r2=r2>>3;
r3=num&000000600;
r3=r3<<3;
r4=num&000005000;
r4=r4>>3;
r5=num&000040000;
r5=r5<<3;
r6=num&000300000;
r6=r6>>3;
r7=num&002000000;
r7=r7<<3;
r8=num&010000000;
r8=r8>>3;
num=r1|r2|r3|r4|r5|r6|r7|r8;*/
r1=num&002040603;
r1=r1<<3;
r2=num&010305070;
r2=r2>>3;
num=r1|r2;

printf("After:%o\n",num);
}
