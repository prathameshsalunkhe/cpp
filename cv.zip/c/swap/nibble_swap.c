#include<stdio.h>
void main()
{
int num=0x11223344,r1,r2,r3;

printf("Before:%x\n",num);

r1=num&0x0000000f;
r1=r1<<28;
r2=num&0xf0000000;
r2=r2>>28;
r3=num&0x0ffffff0;
num=r1|r2|r3;

printf("After:%x\n",num);
}
