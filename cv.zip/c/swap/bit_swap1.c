#include<stdio.h>
void main()
{
int num1=0x2DB6,pos=15,pos1=15,pos2=15,pos3=15,b,r,r1,
result,s;
printf("Before swap= ");
L1:
if(pos>=0)
{
b=num1>>pos&1;
printf("%d",b);
pos=pos-1;
goto L1;
}

printf("\n");

r=num1&0x5555;
r=r<<1;

r1=num1&0xAAAA;
r1=r1>>1;

result=r|r1;

printf("After swap= ");
L2:
if(pos1>=0)
{
s=result>>pos1&1;
printf("%d",s);
pos1=pos1-1;
goto L2;
}

/*for(  ;pos2>=0;pos2-=1)
{
b=num1>>pos2&1;
printf("%d",b);
}
printf("\n");
if(pos3>=0)
{
b=num1>>pos3&1;
printf("%d",b);
pos3=pos3-1;
}
printf("\n");*/

/*r=num1&0x0001;
r=r<<1;

r1=num1&0x0002;
r1=r1>>1;

r2=num1&0x0004;
r2=r2<<1;

r3=num1&0x0008;
r3=r3>>1;

r4=num1&0x0010;
r4=r4<<1;

r5=num1&0x0020;
r5=r5>>1;

r6=num1&0x0040;
r6=r6<<1;

r7=num1&0x0080;
r7=r7>>1;

r8=num1&0x0100;
r8=r8<<1;

r9=num1&0x0200;
r9=r9>>1;

r10=num1&0x0400;
r10=r10<<1;

r11=num1&0x0800;
r11=r11>>1;

r12=num1&0x1000;
r12=r12<<1;

r13=num1&0x2000;
r13=r13>>1;

r14=num1&0x4000;
r14=r14<<1;

r15=num1&0x8000;
r15=r15>>1;

result=r|r1|r2|r3|r4|r5|r6|r7|r8|r9|r10|r11|r12|r13|r14|r15;*/








}
