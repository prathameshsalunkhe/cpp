#include<stdio.h>
void main()
{
int i=46,j=3,k;

//k=i>>j;
k=~i;
//k=i^j;
//k=i|j;
//k=i&j;
printf("k=%d\n",k);
}
