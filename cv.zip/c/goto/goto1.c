#include<stdio.h>
void main()
{
int num,pos=0,s=0,c=0;
printf("Enter the Number:\n");
scanf("%d",&num);

L1:
if(num>>pos&1)
s++;
//else
//c++;
pos++;

if(pos<=31)
goto L1;

printf("set bits=%d\nclear bits=%d\n",s,32-s);

}

