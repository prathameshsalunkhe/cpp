#include<stdio.h>
void main()
{
int num,a,b,sum=0;
printf("Enter the Number:\n");
scanf("%d",&num);

num=num/10;
L1:
if(num>0)
  {
   a=num%10;
   sum+=a;
   num=num/100;
   goto L1;
  } 

printf("sum=%d",sum);

}
