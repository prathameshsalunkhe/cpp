#include<stdio.h>
void main()
{
	int i,j,n,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0,n=1;i<r;i++,n++)
	{
		for(j=0;j<1+2*i;j++)
		{
			if(j%2==0)
				printf("%d",n);
			else
				printf("*");
		}
		printf("\n");
	}

	for(i=0,n=r-1;i<r-1;i++,n--)
	{
		for(j=0; j<(r*2-3)-(i*2) ; j++)
		{

			if(j%2==0)
				printf("%d",n);
			else
				printf("*");

		}
		printf("\n");
	}
}
/*
	int i,j,n;

	for(i=0,n=1;i<5;i++,n++)
	{
		for(j=0;j<1+2*i;j++)
		{
			if(j%2==0)
				printf("%d",n);
			else
				printf("*");
		}
		printf("\n");
	}

	for(i=0,n=4;i<4;i++,n--)
	{
		for(j=0; j<7-(i*2) ; j++)
		{

			if(j%2==0)
				printf("%d",n);
			else
				printf("*");

		}
		printf("\n");
	}
}*/
