#include<stdio.h>
void main()
{
int i,j,ch,r;
printf("Enter The No Of Row:\n");
scanf("%d",&r);

for(i=0,ch='A';i<r;i++)
{
for(j=0;j<=i;j++)
{
if(j==1)
printf("%c ",ch++);
else
printf("* ");
}
printf("\n");
}
}
