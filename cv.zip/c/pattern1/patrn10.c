#include<stdio.h>
void main()
{
int i,j,k,r,n;
printf("Enter The Number Of Rows:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-1-i;k++)
printf("  ");
for(j=0,n=1;j<1+2*i;j++,n++)
printf(" %d",n);
printf("\n");
}

for(i=0;i<r-1;i++)
{
for(k=0;k<=i;k++)
printf("  ");
for(j=0,n=1;j<(r*2-3)-(2*i);j++,n++)
printf(" %d",n);
printf("\n");
}
}
