#include<stdio.h>
void main()
{
int i,j,r,n,m,k;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

for(i=0,n=1;i<r;i++,n++)
{
for(j=0,k=4,m=n;j<=i;j++,k--)
{
printf("%d",m);
m=m+k;
}
printf("\n");
}
}
