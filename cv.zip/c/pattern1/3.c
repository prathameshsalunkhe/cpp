#include<stdio.h>
void main()
{
	int i,j,r,n,k;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(j=0,n=1;j<=i;n++)
		{
			if(j==1)
			{
				printf("* ");
				j++;
			}
			else
			{
				for(k=2;k<n;k++)
				{
					if(n%k==0)
						break;
				}
				if(n==k)
				{
					printf("%d ",n);
				j++;
				}
			}
		}
		printf("\n");
	}
}
