#include<stdio.h>
void main()
{
	int i,j,n,m,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0,n=1;i<r;i++,n++)
	{
		for(j=0,m=n;j<=i;j++,m=m+n)
			printf("%d ",m);
		printf("\n");
	}
}



/*int i,j,n,m;

for(i=0,n=1;i<6;i++,n++)
{
for(j=0,m=n;j<=i;j++,m=m+n)
printf("%d ",m);
printf("\n");
}
}*/
