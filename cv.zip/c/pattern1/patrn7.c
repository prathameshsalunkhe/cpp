#include<stdio.h>
void main()
{
int i,j,n,m,r;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(j=0,n=1,m=2;j<=i;j++)
{
if(i%2==0)
{
printf("%d ",n);
n=n+2;
}
else
{
printf("%d ",m);
m=m+2;
}
}
printf("\n");
}
}


/*
int i,j,n,m;

for(i=0;i<6;i++)
{
for(j=0,n=1,m=2;j<=i;j++)
{
if(i%2==0)
{
printf("%d ",n);
n=n+2;
}
else
{
printf("%d ",m);
m=m+2;
}
}
printf("\n");
}
}*/

