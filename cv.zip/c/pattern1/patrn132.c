#include<stdio.h>
void main()
{
	int i,j,k,l,p,m,n;
	printf("Enter The n:\n");
	scanf("%d",&n);

	for(i=1,m=n+2;i<=n;i++,m=m-2)
	{
		for(j=1;j<i+1;j++)
			printf("%d ",j);
		for(k=0;k<m;k++)
			printf(" ");
		for(p=1,l=j-1;p<i+1;p++,l--)
		{
			if(l==n)
				continue;
			else
				printf(" %d",l);
		}
		printf("\n");
	}
}
