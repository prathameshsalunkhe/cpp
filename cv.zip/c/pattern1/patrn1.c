#include<stdio.h>
void main()
{
int i,j,k,r;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-1-i;k++)
printf(" ");
for(j=0;j<=i;j++)
printf(" *");
printf("\n");
}
for(i=0;i<r-1;i++)
{
for(k=0;k<=i;k++)
printf(" ");
for(j=0;j<r-1-i;j++)
printf(" *");
printf("\n");
}
}


/*
int i,j,k;

for(i=0;i<6;i++)
{
for(k=0;k<5-i;k++)
printf(" ");
for(j=0;j<=i;j++)
printf(" *");
printf("\n");
}
for(i=0;i<5;i++)
{
for(k=0;k<=i;k++)
printf(" ");
for(j=0;j<5-i;j++)
printf(" *");
printf("\n");
}
}*/
