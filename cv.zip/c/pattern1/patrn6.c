#include<stdio.h>
void main()
{
int i,j,r;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(j=0;j<=i;j++)
{
if(j%2==0)
printf("%d",1);
else
printf("%d",0);
}
printf("\n");
}
}
