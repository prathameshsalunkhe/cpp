#include<stdio.h>
void main()
{
	int i,j,k,r;
	printf("Enter The Number Of Row:\n");
	scanf("%d",&r);

	for(i=0;i<r;i++)
	{
		for(k=0;k<r-1-i;k++)
			printf(" ");
		for(j=0;j<1+2*i;j++)
			printf("*");
		printf("\n");
	}
	for(i=0;i<r-1;i++)
	{
		for(k=0;k<=i;k++)
			printf(" ");
		for(j=0;j<(r*2-3)-2*i;j++)
			printf("*");
		printf("\n");
	}
}








/*
int i,j,k;

for(i=0;i<7;i++)
{
for(k=0;k<6-i;k++)
printf(" ");
for(j=0;j<1+2*i;j++)
printf("*");
printf("\n");
}
for(i=0;i<6;i++)
{
for(k=0;k<=i;k++)
printf(" ");
for(j=0;j<11-2*i;j++)
printf("*");
printf("\n");
}
}*/
