#include<stdio.h>
void main()
{
	int i,j,k,n;

	for(i=0;i<5;i++)
	{
		for(j=0,n=1;j<=i;j++,n++)
			printf("%d",n);
		for(k=0;k<7-2*i;k++)
			printf(" ");
			if(i==4)
			n--;
		for(j=0;j<=i;j++)
		{
		if(n!=1)
		printf("%d",--n);
		}
		printf("\n");
	}
}
