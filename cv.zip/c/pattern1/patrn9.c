#include<stdio.h>
void main()
{
int i,j,k,r,n;
printf("Enter The Number:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(k=0;k<r-1-i;k++)
printf("  ");
for(j=0,n=1;j<1+2*i;j++,n++)
printf(" %d",n);
printf("\n");
}
}
