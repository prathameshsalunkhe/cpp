#include<stdio.h>
void main()
{
int i,j,r,ch;
printf("Enter The Number Of Row:\n");
scanf("%d",&r);

for(i=0;i<r;i++)
{
for(j=0,ch='A'+r-1;j<=i;j++)
printf("%c ",ch--);
printf("\n");
}
}
