#include<stdio.h>
int main()
{
	int n;
	printf("Enter The Number Of Elements\n");
	scanf("%d",&n);
	int a[n],ele,i,r=0,r1=0,j;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The elements\n");
	for(i=0;i<ele;i++)
	scanf("%d",&a[i]);
	
	for(j=ele-1;j>=0;j--)
	{
		for(i=0;i<j;i++)
		{
			if(a[i]<a[j])
			{
				r=a[i]*(j-i);
				if(r1<r)
				r1=r;
			}
			else if(a[i]>a[j])
			{
				r=a[j]*(j-i);
				if(r1<r)
				r1=r;
			}

		}
	}
	printf("%d\n",r1);

}
