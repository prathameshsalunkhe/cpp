#include<stdio.h>
int fact(int);
void main()
{
	int num,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	r=fact(num);

	printf("Factorial of %d is:%d\n",num,r);

}

int fact(int num)
{
	static int f=1,n=1;
if(n<=num)
{
f*=n;
n++;
fact(n);
}

	/*static int f=1;
	if(num>=1)
	{
		f*=num;
		num--;
		fact(num);
	}*/
	return f;
}
