#include<stdio.h>
int rev_num(int,int);
void print_palindrome(int *,int);
void main()
{
	int a[6],ele,i;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	print_palindrome(a,ele);

}

void print_palindrome(int *a,int ele)
{
	static int i=0,r,t;
	if(i<ele)
	{
	t=a[i];
		r=rev_num(a[i],t);
	if(r==1)
		printf("%d ",a[i]);
i++;
		print_palindrome(a,ele);
}
}

int rev_num(int num,int t)
{
	static int rev=0,a;
	//t=num;
	a=t%10;
	rev=rev*10+a;
	t/=10;
	if(t)
		rev_num(num,t);
	else if(num==rev)
	{
		rev=0;
		return 1;
		}
	else
	{
		rev=0;
		return 0;
		}
}















/*
void print_palindrome(int *,int);
void main()
{
	int a[6],ele,i;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Elments:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	print_palindrome(a,ele);
}

void print_palindrome(int *a,int ele)
{
	static int i=0,rev=0;
	int b,t;

	t=a[i];
	b=t%10;
	rev=rev*10+b;
	t/=10;
	if(t)
	{
		if(i<ele)
			print_palindrome(a,ele);
	}
	else if(a[i]==rev)
	{
		printf("%d ",a[i]);
		rev=0;
		i++;
		if(i<ele)
			print_palindrome(a,ele);
	}
	else
	{
		i++;
		rev=0;
		if(i<ele)
			print_palindrome(a,ele);
	}
}
*/
