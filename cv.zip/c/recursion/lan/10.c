#include<stdio.h>
int large_ele(int *,int);
void main()
{
	int a[6],i,ele,r;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	r=large_ele(a,ele);

	printf("Largest Element:%d\n",r);
}

int large_ele(int *a,int ele)
{
	static int i=0,L;
	if(i<ele)
	{
		if(a[i]>a[i+1]&&a[i]>L)
			L=a[i];
		else
			i++;
		large_ele(a,ele);
	}
	else
		return L;
}
