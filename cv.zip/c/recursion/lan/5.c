#include<stdio.h>
int factors_sum(int);
void main()
{
	int num,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	r=factors_sum(num);

	printf("Sum Of Factors:%d\n",r);

}

int factors_sum(int num)
{
	static int n=1,sum=0;
	if(num%n==0)
	{
		printf("%d ",n);
		sum+=n;
	}
	n++;
	if(n<num)
		factors_sum(num);
	return sum;
}
