#include<stdio.h>
void print_prime(int);
int prime_check(int,int);
void main()
{
	int num;
	printf("Starting Number:\n");
	scanf("%d",&num);

	print_prime(num);
}

void print_prime(int num)
{
	static int c=0;
	int r,t;
	if(c<100)
	{
		t=num;
		r=prime_check(num,t);
		if(r==1)
		{
			c++;
			printf("%d ",num);

		}
		print_prime(num+1);
	}
}

int prime_check(int num,int t)
{
	static int d=0;
	if(num%t==0)
		d++;
	t--;
	if(t>=1)
		prime_check(num,t);
	else if(d==2)
	{
		d=0;
		return 1;
	}
	else
	{
		d=0;
		return 0;
	}
}

