#include<stdio.h>
void my_rev(char *,int);
int my_strlen(const char *);
void main()
{
	char s[50];
	int len;
	printf("Enter The String:\n");
	scanf("%[^\n]",s);
	len=my_strlen(s);
	my_rev(s,len-1);
	printf("%s\n",s);
}

int my_strlen(const char *s)
{
	static int i=0;
	if(s[i])
	{
		i++;
		my_strlen(s);
	}
	else
		return i;
}

void my_rev(char *s,int len)
{
	static int i=0;
	char t;
	if(i<len)
	{
		t=s[i];
		s[i]=s[len];
		s[len]=t;
		i++;
		len--;
		my_rev(s,len);
	}
}
