#include<stdio.h>
int rev_num(int);
void print_digit_word(int);
void main()
{
	int num,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	printf("Num=%d\n",num);
	r=rev_num(num);
	print_digit_word(r);

}

int rev_num(int num)
{
	static int rev=0,a;
	a=num%10;
	rev=rev*10+a;
	num/=10;
	if(num)
		rev_num(num);
	return rev;
}

void print_digit_word(int r)
{
	int a;
	a=r%10;
	if(a>0)
	{
		switch(a)
		{
			case 0:printf("Zero ");
			       break;
			case 1:printf("One ");
			       break;
			case 2:printf("Two ");
			       break;
			case 3:printf("Three ");
			       break;
			case 4:printf("Four ");
			       break;
			case 5:printf("Five ");
			       break;
			case 6:printf("Six ");
			       break;
			case 7:printf("Seven ");
			       break;
			case 8:printf("Eight ");
			       break;
			case 9:printf("Nine ");
			       break;
		}
	}
	r/=10;
	if(r)
		print_digit_word(r);
}
