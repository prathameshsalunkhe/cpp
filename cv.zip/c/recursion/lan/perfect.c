#include<stdio.h>
void print_perfect(int);
int perfect_check(int);
void main()
{
	int num;
	printf("Starting Number:\n");
	scanf("%d",&num);

	print_perfect(num);
}

void print_perfect(int num)
{
	static int c=0;
	int r,t;
	if(c<5)
	{
		r=perfect_check(num);
		if(r==1)
		{
			c++;
			printf("%d ",num);

		}
		print_perfect(num+1);
	}
}

int perfect_check(int num)
{
	static int d=1,sum=0;
	if(num%d==0)
		sum+=d;
	d++;;
	if(d<num)
		perfect_check(num);
	else if(sum==num)
	{
		d=1;
		sum=0;
		return 1;
	}
	else
	{
		d=1;
		sum=0;
		return 0;
	}
}

