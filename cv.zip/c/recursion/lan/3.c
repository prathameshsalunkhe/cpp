#include<stdio.h>
int sum_digit(int);
void main()
{
	int num,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	r=sum_digit(num);

	printf("Sum=%d\n",r);

}

int sum_digit(int num)
{
	static int a,sum=0;
	a=num%10;
	sum+=a;
	num/=10;
	if(num)
		sum_digit(num);
	return sum;
}
