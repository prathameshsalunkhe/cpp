#include<stdio.h>
void print_binary(int);
void revrse_bits(int *);
void main()
{
	int num,*p;
	printf("Enter The Number:\n");
	scanf("%d",&num);
	p=&num;
	printf("Before:");
	print_binary(num);
	printf("\n");
	revrse_bits(&num);
	printf("After:");
	print_binary(num);
}

void print_binary(int num)
{
	static int pos=31;
	if(pos>=0)
	{
		printf("%d",num>>pos&1);
		pos--;
		print_binary(num);
	}
	else
		pos=31;
}

void revrse_bits(int *p)
{
	static int i=0,j=31;
	int m,n;
	if(i<j)
	{
		m=*p>>i&1;
		n=*p>>j&1;
		if(m!=n)
		{
			*p=*p^1<<i;
			*p=*p^1<<j;
		}
		i++;
		j--;
		revrse_bits(p);
	}
}
