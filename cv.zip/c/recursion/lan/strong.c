#include<stdio.h>
void print_strong(int);
int strong_check(int,int);
void main()
{
	int num;
	printf("Starting Number:\n");
	scanf("%d",&num);

	print_strong(num);
}

void print_strong(int num)
{
	static int c=0;
	int r,t;
	if(c<2)
	{
		t=num;
		r=strong_check(num,t);
		if(r==1)
		{
			c++;
			printf("%d ",num);

		}
		print_strong(num+1);
	}
}

int strong_check(int num,int t)
{
	static int d=1,sum=0,mul=1;
	 int a;
	a=t%10;

	mul*=d;
	d++;
	if(d<=a)
		strong_check(num,t);
		sum+=mul;
		mul=1;
		d=1;
		t/=10;
	 if(t)
		strong_check(num,t);
	else if(sum==num)
	{
		d=1;
		mul=1;
		sum=0;
		return 1;
	}
	else
	{
		d=1;
		mul=1;
		sum=0;
		return 0;
	}
}

