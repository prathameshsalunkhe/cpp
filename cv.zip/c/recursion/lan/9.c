#include<stdio.h>
void perfect_num(int);
void main()
{
	int num;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	perfect_num(num);
}

void perfect_num(int num)
{
	static int i=1,sum=0;
	if(i<num)
	{
		if(num%i==0)
			sum+=i;
		i++;
		perfect_num(num);
	}
	else if(sum==num)
		printf("Number is Perfect\n");
	else
		printf("Number is Not Perfect\n");
}

