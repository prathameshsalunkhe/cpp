#include<stdio.h>
void rev_element(int *,int);
void main()
{
	int a[6],i,ele;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	rev_element(a,ele);

	for(i=0;i<ele;i++)
		printf("%d ",a[i]);
}

void rev_element(int *a,int ele)
{
	static int i=0;
	int t;
	if(i<ele)
	{
		t=a[i];
		a[i]=a[ele-1];
		a[ele-1]=t;
		i++;
		ele--;
		rev_element(a,ele);
	}
}


