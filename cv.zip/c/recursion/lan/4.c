#include<stdio.h>
void num_rev(int *);
void main()
{
	int num,*p;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	printf("Before Num:%d\n",num);
	p=&num;
	num_rev(p);

	printf("After Num:%d\n",num);

}

void num_rev(int *p)
{
	static int rev=0,a;
	a=*p%10;
	rev=rev*10+a;
	*p/=10;
	if(*p)
		num_rev(p);
	*p=rev;
}

/*
int num_rev(int);
void main()
{
	int num,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	printf("Before:%d\n",num);

	r=num_rev(num);

	printf("After:%d\n",r);

}

int num_rev(int num)
{
	static int rev=0;
	int a;
	a=num%10;
	rev=rev*10+a;
	num/=10;
	if(num)
		num_rev(num);
	return rev;
}*/
