#include<stdio.h>
void fibonacci(int,int);
void main()
{
	int a,b;
	printf("Enter The Starting & Ending Number:\n");
	scanf("%d%d",&a,&b);

	fibonacci(a,b);

}

void fibonacci(int a,int b)
{
	static int z,x=0,y=1;
	int c=x;
	if(a<b)
	{
		printf("%d ",x);
		z=x+y;
		x=y;
		y=z;
		c=x;
		if(c<=b)	
		fibonacci(a+1,b);

	}
}
