#include<stdio.h>
int rec_fun_sum(int);
void main()
{
	int num,sum;
	printf("Enter The Number:\n");
	scanf("%d",&num);
	num=num%1000;
	sum=rec_fun_sum(num);
	printf("sum=%d\n",sum);
}

int rec_fun_sum(int num)
{
	static int a,sum=0;
	a=num%10;
		sum+=a;
	num/=10;
	if(num)
		rec_fun_sum(num);
	else
		return sum;
}
