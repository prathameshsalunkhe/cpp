#include<stdio.h>
int my_strncmp(char *,char *,int);
void main()
{
	char m[50],s[50];
	int n,r;
	printf("Enter The Main String:\n");
	scanf("%[^\n]",m);
	printf("Enter The Sub String:\n");
	scanf(" %[^\n]",s);
	printf("Enter The index Number:");
	scanf("%d",&n);

        r=my_strncmp(m,s,n);
	if(r==1)
	printf("Both Strings Are Same\n");
	else
	printf("Both Strings Are Not Same\n");
}

int my_strncmp(char *m,char *s,int n)
{
	static int i=0;
	if(i<n)
	{
		if(m[i]!=s[i])
		return 0;
		i++;
		my_strncmp(m,s,n);
	}
	else if(i==n)
	return 1;
	else
	return 0;
		
}
