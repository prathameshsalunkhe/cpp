#include<stdio.h>
void my_strncpy(char *,char *,int);
void main()
{
	char s[50],d[30];
	int n;
	printf("Enter The String:\n");
	scanf("%[^\n]",s);
	printf("Enter The index Number:");
	scanf("%d",&n);

	printf("Before: %s\n",d);

	my_strncpy(d,s,n);

	printf("After: %s\n",d);
}

void my_strncpy(char *d,char *s,int n)
{
	static int i=0;
	if(i<n)
	{
		d[i]=s[i];
		i++;
		my_strncpy(d,s,n);
	}
	else
		d[i]='\0';
}
