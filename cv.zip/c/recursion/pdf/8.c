#include<stdio.h>
int rec_fun_prime(int,int);
void main()
{
	int num,t,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	t=num;

	r=rec_fun_prime(num,t);
	if(r==1)
		printf("Number is Prime\n");
	else
		printf("Number is Not Prime\n");
}

int rec_fun_prime(int num,int t)
{
	static int c=0;
	if(num%t==0)
		c++;
	t--;
	if(t>=1)
		rec_fun_prime(num,t);
	else if(c==2)
		return 1;
	else
		return 0;
}
