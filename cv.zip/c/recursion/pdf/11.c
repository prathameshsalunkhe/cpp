#include<stdio.h>
void rec_fun_rev_arr(int *,int *);
void main()
{
int a[6],ele,i,*p,*q;
ele=sizeof(a)/sizeof(a[0]);
printf("Enter The Element:\n");
for(i=0;i<ele;i++)
scanf("%d",&a[i]);

printf("Before:");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");

p=a;
q=&a[ele-1];

rec_fun_rev_arr(p,q);

printf("Before:");
for(i=0;i<ele;i++)
printf("%d ",a[i]);
printf("\n");
}

void rec_fun_rev_arr(int *p,int *q)
{
 int t;
t=*p;
*p=*q;
*q=t;
p++;
q--;
if(p<q)
rec_fun_rev_arr(p,q);
}
