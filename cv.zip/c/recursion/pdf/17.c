#include<stdio.h>
char *my_strchr(char *,char);
void main()
{
char s[50],ch,*p;
printf("Enter The String:\n");
scanf("%[^\n]",s);
printf("Enter The Character:\n");
scanf(" %c",&ch);

p=my_strchr(s,ch);
if(p!=0)
printf("Char is Present in %p Location\n",p);
else
printf("Char Is Not Present\n");

}

char *my_strchr(char *s,char ch)
{
static int i=0;
if(s[i])
{
if(s[i]==ch)
return s+i;
i++;
my_strchr(s,ch);
}
else
return 0;
//printf("Char Is Not Present\n");
}
