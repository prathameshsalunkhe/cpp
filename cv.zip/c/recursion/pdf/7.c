#include<stdio.h>
int rec_fun_count(int *);
void main()
{
	int num,c,*p;
	printf("Enter The Number:\n");
	scanf("%d",&num);
	p=&num;
	c=rec_fun_count(p);
	printf("Count Of Set Bit:%d\n",c);
}

int rec_fun_count(int *num)
{
	static int c=0,pos=31;
	if(*num>>pos&1)
		c++;
	pos--;
	if(pos>=0)
		rec_fun_count(num);
	else
		return c;
}
