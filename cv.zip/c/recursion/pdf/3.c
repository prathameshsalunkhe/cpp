#include<stdio.h>
int rec_fun_sum(int);
void main()
{
	int num,product;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	product=rec_fun_sum(num);
	printf("product=%d\n",product);
}

int rec_fun_sum(int num)
{
	static int a,product=1;
	a=num%10;
	if(a%3==0)
		product*=a;
	num/=10;
	if(num)
		rec_fun_sum(num);
	else
		return product;
}
