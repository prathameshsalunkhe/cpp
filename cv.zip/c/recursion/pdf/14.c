#include<stdio.h>
int rec_fun_rev_bit(int);
void rec_fun_binary(int);
void main()
{
	int num,rev;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	printf("Before:");
	rec_fun_binary(num);
	printf("\n");

	rev=rec_fun_rev_bit(num);

	printf("After:");
	rec_fun_binary(rev);

}

void rec_fun_binary(int num)
{
	static int pos=31;
	printf("%d",num>>pos&1);
	if(pos%8==0)
		printf(" | ");
	pos--;
	if(pos>=0)
		rec_fun_binary(num);
	else
		pos=31;
}

int rec_fun_rev_bit(int num)
{
	static int i=0,j=31,m,n;
	if(i<j)
	{
		if(num>>i&1!=num>>j&1)
		{
		num=num^1<<i^1<<j;
		//num=num^1<<i;
		//num=num^1<<j;
		}
		i++;
		j--;
		rec_fun_rev_bit(num);
	}
	else
		return num;
}
