#include<stdio.h>
int rec_fun_sum(int);
void main()
{
	int num,count;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	count=rec_fun_sum(num);
	printf("count=%d\n",count);
}

int rec_fun_sum(int num)
{
	static int a,c=0;
	a=num%10;
	if(a<6)
		c++;
	num/=10;
	if(num)
		rec_fun_sum(num);
	else
		return c;
}
