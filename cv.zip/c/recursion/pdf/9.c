#include<stdio.h>
int rec_fun_count_arr(int *,int);
void main()
{
	int a[6],ele,i,c;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	c=rec_fun_count_arr(a,ele);
	printf("Count=%d\n",c);
}

int rec_fun_count_arr(int *a,int ele)
{
	static int c=0,i=0;
	if(a[i]>39 && a[i]<99)
		c++;
	i++;
	if(i<ele)
		rec_fun_count_arr(a,ele);
	else
		return c;
}
