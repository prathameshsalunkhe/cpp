#include<stdio.h>
int rec_fun_perfect(int);
void main()
{
	int num,r;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	r=rec_fun_perfect(num);
	if(r==1)
		printf("Yes Number Is Perfect\n");
	else
		printf("Yes Number Is Not Perfect\n");
}

int rec_fun_perfect(int num)
{
	static int sum=0,n=1;
	if(num%n==0)
		sum+=n;
	n++;
	if(n<num)
		rec_fun_perfect(num);
	else if(sum==num)
		return 1;
	else
		return 0;
}


