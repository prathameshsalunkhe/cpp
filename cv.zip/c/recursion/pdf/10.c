#include<stdio.h>
int rec_fun_sum_arr(int *,int);
void main()
{
	int a[6],ele,i,sum;
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	sum=rec_fun_sum_arr(a,ele/2);
	printf("Sum=%d\n",sum);
}

int rec_fun_sum_arr(int *a,int ele)
{
	static int sum=0,i=0;
	sum+=a[i];
	i++;
	if(i<ele)
		rec_fun_sum_arr(a,ele);
	else
		return sum;
}

