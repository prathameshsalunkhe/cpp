#include<stdio.h>
void rec_fun_rev_string(char *,char *);
void main()
{
char s[50],*p,*q;
int len;
printf("Enter The String:\n");
scanf("%[^\n]",s);

for(len=0;s[len];len++);
printf("Before: %s\n",s);

p=s;
q=&s[len-1];

rec_fun_rev_string(p,q);
//printf("After: %s\n",s);
}

void rec_fun_rev_string(char *p,char *q)
{

printf("%c",*q);
q--;
if(q>=p)
rec_fun_rev_string(p,q);
}
