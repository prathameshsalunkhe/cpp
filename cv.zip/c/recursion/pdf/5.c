#include<stdio.h>
int rec_fun_rev(int);
void main()
{
	int num,num1;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	num1=rec_fun_rev(num);
	printf("Rev Num=%d\n",num1);
}

int rec_fun_rev(int num)
{
	static int rev=0,a;
	a=num%10;
	rev=rev*10+a;
	num/=10;
	if(num)
		rec_fun_rev(num);
	else
		return rev;
}
