#include<stdio.h>
int rec_fun_count_string(char *,char);
void main()
{
char s[50],ch;
int c;
printf("Enter The String:\n");
scanf("%[^\n]",s);
printf("Enter The Character:\n");
scanf(" %c",&ch);

c=rec_fun_count_string(s,ch);
printf("Count=%d\n",c);
}

int rec_fun_count_string(char *s,char ch)
{
static int i=0,c=0;
if(s[i]==ch)
c++;
i++;
if(s[i])
rec_fun_count_string(s,ch);
else
return c;
}
