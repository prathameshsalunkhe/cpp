#include<stdio.h>
int rec_fun_sum(int);
void main()
{
	int num,sum;
	printf("Enter The Number:\n");
	scanf("%d",&num);

	sum=rec_fun_sum(num);
	printf("sum=%d\n",sum);
}

int rec_fun_sum(int num)
{
	static int a,sum=0;
	a=num%10;
	if(a%2==0)
		sum+=a;
	num/=10;
	if(num)
		rec_fun_sum(num);
	else
		return sum;
}
