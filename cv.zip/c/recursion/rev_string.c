#include<stdio.h>
void print_string(const char *);
void main()
{
	char s[50];
	printf("Enter The String:\n");
	scanf("%s",s);
	print_string(s);

}

void print_string(const char *s)
{
	if(*s)
	{
		print_string(s+1);
		printf("%c",*s);
	}
}

