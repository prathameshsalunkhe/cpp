#include<stdio.h>
void my_strcpy(char *,const char *);
void main()
{
char s[50],d[50];
printf("Enter The String:\n");
scanf("%[^\n]",s);

printf("Before:%s\n",d);
my_strcpy(d,s);
printf("Aftre:%s\n",d);
}

void my_strcpy(char *d,const char *s)
{
if(*s)
{
*d=*s;
my_strcpy(d+1,s+1);
}
else
*d=*s;
}
