#include<stdio.h>
int my_strlen(const char *);
void main()
{
	char s[50];
	int len;
	printf("Enter The String:\n");
	scanf("%s",s);

	len=my_strlen(s);
	printf("len=%d\n",len);
}

int my_strlen(const char *s)
{
	static int c=0;
	if(*s)
	{
		c++;
		my_strlen(s+1);
		//return c;
	}
	else
		return c;
}
