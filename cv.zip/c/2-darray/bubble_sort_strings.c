#include<stdio.h>
#include<string.h>
void main()
{
	char s[3][10],t[10];
	int i,ele,j;

	ele=sizeof(s)/sizeof(s[0]);

	printf("Enter The 3 Strings:\n");
	for(i=0;i<ele;i++)
		scanf("%s",s[i]);

	printf("Before:");
	for(i=0;i<ele;i++)
		printf("%s\n",s[i]);

	for(i=0;i<ele-1;i++)
	{
		for(j=0;j<ele-1-i;j++)
		{
			//if(strcmp(s[j],s[j+1])>0)
			if(strlen(s[j])>strlen(s[j+1]))
			{
				strcpy(t,s[j]);
				strcpy(s[j],s[j+1]);
				strcpy(s[j+1],t);
			}
		}
	}

	printf("After:");
	for(i=0;i<ele;i++)
		printf("%s\n",s[i]);
}
