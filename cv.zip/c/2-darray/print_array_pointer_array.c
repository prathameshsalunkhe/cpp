#include<stdio.h>
void main()
{
	int a[5],ele,i,(*p)[5];
	ele=sizeof(a)/sizeof(a[0]);
	printf("Enter The Element:\n");
	for(i=0;i<ele;i++)
		scanf("%d",&a[i]);

	p=&a;

	for(i=0;i<ele;i++)
		printf("%d ",(*p)[i]);
	printf("\n");
}
