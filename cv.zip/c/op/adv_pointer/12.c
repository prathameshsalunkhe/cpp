#include <stdio.h>
        void main()
        {
            char *a[10] = {"hi", "hello", "how"};
            printf("%d\n", sizeof(a[1]));
        }
