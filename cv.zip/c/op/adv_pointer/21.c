#include<stdio.h>
	main()
	{
		char *m[]={"jan","feb","mar"};
		char d[][10] = {"sun","mon","tue"};
		printf("%s\t",m[1]);
		printf("%s\t",d[1]);
	}
