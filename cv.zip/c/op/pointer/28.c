#include<stdio.h>
       int main()
       {
	char *x = "VECTOR";
	printf("%s\n",x+3);
	printf("%d\n"+1,123456);
       }
