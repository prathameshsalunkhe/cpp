#include <stdio.h>
        void main()
        {
            char *s = "hello";
            char *n = "cjn";
               s++;  
            printf("%c  %c", *s , n[1]);
        }
