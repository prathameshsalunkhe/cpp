#include<stdio.h>
int main()
{
	int num,i=0;
	num=-++i+ ++(-i);
	printf("%d",num);
	return 0;
}
