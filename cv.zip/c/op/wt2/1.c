#include<stdio.h> 
int a=5;
void main()
{ 
	int x; 
	x=!a+change(); 
	printf("%d",x); 
} 
int change()
{ 
	a=0; return 0;
}
