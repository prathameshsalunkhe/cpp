#include<stdio.h>
void main()
{
	int i;
	for (i=5; ++i; i-=3)
		printf("%d" ,i);
}
