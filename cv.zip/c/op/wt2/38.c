#include<stdio.h>
extern int i=10;
int f(int i)
{
	return(++i*i); 
} 
void main() 
{
	extern int i;
	printf("%d",f(i));
}
