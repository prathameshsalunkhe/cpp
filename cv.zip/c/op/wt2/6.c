#include<stdio.h>
void main() 
{ 
	int i,j;
	i=1; 
	j=1; 
	while(i^j || i-- || --j)
		printf("%d %d",i,j); 
}
