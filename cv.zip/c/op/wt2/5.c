#include<stdio.h>
int main()
{
	int x=011,i;
	for(i=0;i<x;i+=3)
	{
		printf("Start ");
		continue;
		printf("End");
	}
	return 0;
}
