#include<stdio.h>
void main() 
{ 
	int a=5;
	a=find(a+=find(a++));
	printf("%d",a);
}
int find(int a) 
{ 
	return(a++); 
}
