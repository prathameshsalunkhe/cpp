#include<stdio.h>
void main( )
{
	int i = 4;
	printf("%d,%d,%d", sizeof(i), sizeof(4), sizeof('4'));
}
