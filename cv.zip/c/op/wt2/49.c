#include<stdio.h>
void main()
{
	f();
	f();
}
f()
{
	static int i=1;
	printf("%d",i++);
	i=i--,i++,i=i-2;
	i=(i++,i=i-2);
}
