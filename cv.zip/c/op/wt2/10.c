#include<stdio.h>
void main()
{
printf("%d %d\n",sizeof('*'),sizeof(int));
}


