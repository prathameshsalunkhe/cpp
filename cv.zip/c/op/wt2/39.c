#include<stdio.h>
void main()
{
	int i=40;
	do
	{
		printf("%d",i++);
	} 
	while(5,4,3,2,1,i-41);
	return 0;
}
