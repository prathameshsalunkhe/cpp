#include<stdio.h>
void main()
{
	int x=3,y=3,z=3;
	z-=x-- - --y;
	printf("x=%d y=%d z=%d", x, y, z);
}
