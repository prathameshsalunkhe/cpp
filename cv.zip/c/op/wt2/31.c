#include<stdio.h>
int main()
{
	int i=2;
	int j = i + (1, 2, 3, 4, 5);
	printf("%d", j);
	return 0;
}
